/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SimpleRobot;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class RobotTemplate extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    public void autonomous() {
        
    }

    /**
     * This function is called once each time the robot enters operator control.
*/
     public void operatorControl() {
         Elevator elevator = new Elevator(1);
         DriverStationLCD lcd = DriverStationLCD.getInstance();
         Joystick stick = new Joystick(1);
        String aString = null;
        double target = 0;
        boolean up = true, prevUp=true;
        boolean down = true, prevDown=true;
         while(isOperatorControl()){
             /*if(stick.getY() > .05)
              elevator.ElevatorUp();
             if(stick.getY() < -.05)
              elevator.ElevatorDown();
             if(stick.getY() > -.05 && stick.getY() <.05)
              elevator.ElevatorRest();
             /*if(stick.getRawButton(3)){ //10,11,7,6,3(base) //BASE
               elevator.Update(0);
                 }             
             if(stick.getRawButton(6)){ //Position 1
                 //elevator.LevelOne();
                 elevator.Update(10);
             }
             if(stick.getRawButton(7)){ //Position 2
                 elevator.Update(20);
                 }
            if(stick.getRawButton(10)){ //Position 3
                 elevator.Update(30);
                 }
            if(stick.getRawButton(11)){ //Position 4
                 elevator.Update(40);
                 }
             if(stick.getRawButton(2)){
                 if(stick.getY() > .05)
              elevator.ElevatorUp();
             if(stick.getY() < -.05)
              elevator.ElevatorDown();
             if(stick.getY() > -.05 && stick.getY() <.05)
              elevator.ElevatorRest();
                 if(stick.getTrigger(Hand.kLeft)){
                     ////Distance convert from Double to String////
                    //aString = Double.toString(Elevator.Distance());
                    lcd.println(DriverStationLCD.Line.kMain6,1,aString);
                 }
             }*/


             if(stick.getRawButton(2)) target = 3000;
             if(stick.getRawButton(4)) target = 0;
             if(stick.getRawButton(3)){
                 up = false;
                 prevUp = false;
             } else{
                 up = true;
                 if(!(up && prevUp)){
                     target += 250;
                 }
                 prevUp = true;
             }
             if(stick.getRawButton(1)){
                 down = false;
                 prevDown = false;
             } else{
                 down = true;
                 if(!(down && prevDown)){
                     target -= 250;
                 }
                 prevDown = true;
             }
             DriverStationLCD.getInstance().println(DriverStationLCD.Line.kUser3, 1, "Target: "+target);
             elevator.Update(target);
     }
     //elevator.Update(0);


}

}
    

