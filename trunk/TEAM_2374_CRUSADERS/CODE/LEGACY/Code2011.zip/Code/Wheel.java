/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.PIDController;
import edu.wpi.first.wpilibj.PIDOutput;

/**
 *
 * @author robotics
 */
public class Wheel implements PIDOutput{ //It controls itself!!!

    //Static variables
    private static final double DEFAULT_TIMEOUT = 1000; //Safety time out for the motors
    private static final double kP = 0.1, kI = 0.0, kD = 0.0; //PID Constants
    public static final double MAX_ENCODER_RATE = 1600;


    //The super shifters have 2 motors to one gearbox
    private Jaguar motorOne;
    private Jaguar motorTwo;
    
    //The wheel's encoder.
    private RateEncoder encoder;

    //The self contained PID controller for the wheel
    private PIDController wheelPID;


    /**
     * Constructs a Wheel object with 2 Jaguars. Enables the safety to 1 second
     * @param motor1Port The port for one motor of the wheel
     * @param motor2Port The port for another motor of the wheel
     */
    public Wheel(int motor1Port, int motor2Port, int encoderPort1, int encoderPort2){
        
        //The wheel controls both motors
        motorOne = new Jaguar(motor1Port);
        motorTwo = new Jaguar(motor2Port);

        //No more global watchdog, now there are "watchdogs" called MotorSafety's on the motors
        motorOne.setSafetyEnabled(true); motorOne.setExpiration(DEFAULT_TIMEOUT);
        motorTwo.setSafetyEnabled(true); motorTwo.setExpiration(DEFAULT_TIMEOUT);

        //There's a bug with the EncodingType.k1x getRate function. Switch this to true if the encoder is backwards
        encoder = new RateEncoder(encoderPort1,encoderPort2, false, EncodingType.k2X);

        //This allows the wheel to control itself from its own encoder
        wheelPID = new PIDController(kP,kI,kD,encoder,this);
        wheelPID.setInputRange(-1*MAX_ENCODER_RATE,1*MAX_ENCODER_RATE); //Set the input range to the scaled PWM range
        wheelPID.setOutputRange(-1*MAX_ENCODER_RATE, 1*MAX_ENCODER_RATE); //Set the output range to the scaled PWM range

        encoder.start(); //Start the encoder in order to get data
        wheelPID.enable(); //Enable the PID for it to work
    }

    /**
     * Directly sets the wheel's speed. Use this without PID
     * @param speed The speed to apply to both motors of the Super Shifter
     */
    public void set(double speed){
        encoder.update();
        motorOne.set(speed);
        motorTwo.set(speed);
    }

    /**
     * Set the setpoint of the wheel's PID. Use this with PID instead of Wheel.set()
     * @param speed The speed to set the setpoint. Make sure this is within -MAX_ENCODER_RATE and MAX_ENCODER_RATE
     */
    public void setTargetSpeed(double speed){
        DriverStationLCD.getInstance().println(DriverStationLCD.Line.kMain6, 1, "Input: "+speed);
        wheelPID.setSetpoint(speed);
    }

    /**
     * Interface method for PIDOutput
     * @param output The output of the PID controller
     */
    public void pidWrite(double output) {
        DriverStationLCD.getInstance().println(DriverStationLCD.Line.kUser2, 1, "Output: "+output);
        this.set(output / MAX_ENCODER_RATE); //scale it down to PWM range
    }

    /**
     * Gets the wheel's RateEncoder
     * @return this instance's RateEncoder
     */
    public RateEncoder getEncoder(){
        return this.encoder;
    }
    


}
