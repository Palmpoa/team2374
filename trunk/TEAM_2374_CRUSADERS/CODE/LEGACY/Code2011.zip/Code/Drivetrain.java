/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

/**
 *
 * @author robotics
 */
public class Drivetrain {

    public static final double DEADBAND_SIZE = 0.05;

    private Wheel leftWheel, rightWheel;

    public Drivetrain(){
        leftWheel = new Wheel(1,2,1,3);
        rightWheel = new Wheel(3,4,5,7);
    }

    /**
     * Accounts a deadband for a value
     * @param input The value to adjust
     * @return A deadband adjusted value
     */
    public double deadBandModifier(double input){
        if(Math.abs(input)<= DEADBAND_SIZE) return 0;
        return input;
    }

    //Tank drive right now
    public void update(double stick1Y, double stick2Y){

        double temp1 = deadBandModifier(stick1Y);
        double temp2 = deadBandModifier(stick2Y);

        //This should be in its own function. It just clamps the joystick to -1 to 1
        if(temp1 > 1) temp1 = 1;
        if(temp1 < -1) temp1 = -1;
        if(temp2 > 1) temp2 = 1;
        if(temp2 < -1) temp2 = -1;
        
        leftWheel.setTargetSpeed(deadBandModifier(temp1)*Wheel.MAX_ENCODER_RATE);
        //rightWheel.set(deadBandModifier(temp2)); //Currently there is no right wheel
    }

    public Wheel getRightWheel(){ return rightWheel; }
    public Wheel getLeftWheel() { return leftWheel; }

    

    


}
