/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.Servo;
import edu.wpi.first.wpilibj.camera.AxisCamera;
import edu.wpi.first.wpilibj.image.*;

/**
 *
 * @author robotics
 */
public class Rufus {
    AxisCamera rufus;
    Servo pan, tilt;

    public Rufus(){
        rufus = AxisCamera.getInstance();
        pan = new Servo(7);
        tilt = new Servo(8);
        NIVision.setWriteFileAllowed(true);
        update(0,0);
    }

    public void update(double p, double t){
        pan.set(p);
        tilt.set(-0.5*t + 0.5); //it is centered at 0.5
    }

    public void findBlobs(int r, int g, int b){

        //+/- 25%
        int rLow = (int)(r*0.75 + 0.5);
        int rHigh = (int)(r*1.25 + 0.5);
        int gLow = (int)(g*0.75 + 0.5);
        int gHigh = (int)(g*1.25 + 0.5);
        int bLow = (int)(b*0.75 + 0.5);
        int bHigh = (int)(b*1.25 + 0.5);

        DriverStationLCD lcd = DriverStationLCD.getInstance();

        try{
            ColorImage original = rufus.getImage();
            BinaryImage masked = original.thresholdRGB(rLow, rHigh, gLow, gHigh, bLow, bHigh);
            masked.write("masked.bmp");
            lcd.println(DriverStationLCD.Line.kMain6, 1, "Number of Blobs: "+masked.getNumberParticles());
            if(masked.getNumberParticles() > 0){
                ParticleAnalysisReport bigBlob = masked.getOrderedParticleAnalysisReports(1)[0];
                lcd.println(DriverStationLCD.Line.kUser2, 1,
                        "Blob percent: "+bigBlob.particleToImagePercent);
                if(bigBlob.particleToImagePercent > 7){
                    double xDirection = -bigBlob.center_mass_x / Math.abs(bigBlob.center_mass_x);
                    double yDirection = bigBlob.center_mass_y / Math.abs(bigBlob.center_mass_y);
                    //this.update(pan.get()+xDirection*0.1,tilt.get()+yDirection*0.1);
                    double cleanerX = ((int)(100*bigBlob.center_mass_x_normalized)) / 100.0;
                    double cleanerY = ((int)(100*bigBlob.center_mass_y_normalized)) / 100.0;
                    lcd.println(DriverStationLCD.Line.kUser3,1,
                            "Blob: ("+cleanerX+", "+cleanerY+")        ");
                }
                else{
                    lcd.println(DriverStationLCD.Line.kUser3, 1, "                            ");
                }
            }
            else{
                lcd.println(DriverStationLCD.Line.kUser2, 1, "N/A");
            }
            lcd.getInstance().updateLCD();
            masked.free();
            original.free();

        }catch(Exception e){/*
            Sorry I could not catch the exception. There is a bunny in my code.
            (\_/)
            (=-.-)
            C(")(")
        */
            e.printStackTrace();
        }

        
    }
}
