/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import edu.wpi.first.wpilibj.DigitalInput;

/**
 *
 * @author Zuhair
 */
public class LineSensorGroup {

       //These are all the possible cases
       public static final int 
        ALL_OFF = 0,
        DRIFTED_LEFT = 1,
        ON_LINE = 2,
        DRIFTED_LEFT_Y = 3,
        DRIFTED_RIGHT = 4,
        PAST_Y = 5,
        DRIFTED_RIGHT_Y = 6,
        AT_T = 7;


       DigitalInput lsLeft, lsMiddle, lsRight;

       public LineSensorGroup(int portLeft, int portMiddle, int portRight){
           lsLeft = new DigitalInput(portLeft);
           lsMiddle = new DigitalInput(portMiddle);
           lsRight = new DigitalInput(portRight);
       }

       public int getCase(){

           //Turn T/F into 1/0
           int left = lsLeft.get()?1:0;
           int middle = lsMiddle.get()?1:0;
           int right = lsRight.get()?1:0;

           return 4*left+ 2*middle+ 1*right; //binary to decimal conversion
       }



    
}
