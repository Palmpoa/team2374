/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package com.team2374;


import edu.wpi.first.wpilibj.SimpleRobot;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    Drivetrain drivetrain = new Drivetrain();
    LineSensorGroup lsg = new LineSensorGroup(1,2,3); //TODO: Fix these
    public void autonomous() {
        goForwardUntilLineFound();
    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {

    }

    public void goForwardUntilLineFound(){
        while(lsg.getCase() != LineSensorGroup.ON_LINE){
            drivetrain.update(0.75, 0.75);
        }
    }
    public void goForwardUntilAtT(){
        while(true){

            int reading = lsg.getCase();

            switch (reading){
                case LineSensorGroup.ALL_OFF: return; //beyond hope

                case LineSensorGroup.ON_LINE: drivetrain.update(0.5, 0.5); break;

                case LineSensorGroup.DRIFTED_LEFT:
                case LineSensorGroup.DRIFTED_RIGHT: drivetrain.setAngle(0); break;

                case LineSensorGroup.AT_T: drivetrain.update(0, 0); return;
            }

        }
    }
}
