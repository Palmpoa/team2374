/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Zuhair
 */
public class UDPHandler {
    
    String ipAddressDest;
    int portSend, portRcv;

    DatagramSocket sendingSocket;
    InetSocketAddress crioAddress;

    public UDPHandler(String ipdest, int portsend, int portrcv){

        try {
            sendingSocket = new DatagramSocket();
            crioAddress = new InetSocketAddress(ipdest,portsend);
        } catch (SocketException ex) {
            Logger.getLogger(UDPHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendPacket(byte[] data) throws IOException{
        DatagramPacket packet = new DatagramPacket(data, data.length);
        packet.setSocketAddress(crioAddress);
        sendingSocket.send(packet);
    }

    public static void main(String[] args) throws IOException{
        UDPHandler handler = new UDPHandler("192.168.1.105",12345,1337);

        byte[] data = "This is a test message!".getBytes();

        handler.sendPacket(data);

    }

}
