/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package opr;

/**
 *
 * @author ian Walters
 */
public class OPR {
    private static boolean isSymmetric(double[][] A){
        int N = A.length;
        for (int i = 0; i < N; i++) {
            for(int j = 0; j < i; j++){
                if(A[i][j] != A[j][i]){
                    return false;
                }
            }
        }
        return true;
    }

    private static boolean isSquare(double[][] A){
        int N = A.length;
        for (int i = 0; i < N; i++) {
            if(A[i].length != N){
                return false;
            }
        }
        return true;
    }

    //Decomposed the matrix into a lower triangluar
    public static double[][] cholesky(double[][] A){
        if(!isSquare(A) || !isSymmetric(A)){
            throw new RuntimeException("Matrix is not square or not symmetric");
        }
        int N = A.length;
        double[][] L = new double[N][N];
        for(int i = 0; i < N; i++){
            for(int j = 0; j <= i; j++){
                double sum = 0;
                for(int k = 0; k < j; k++){
                    double value = L[i][k]*L[j][k];
                    sum += value;
                }
                if(i == j){
                    L[i][i] = Math.sqrt(A[i][i] - sum);
                }
                else{
                    L[i][j] = 1.0/L[j][j] * (A[i][j] - sum);
                }
            }
            if(L[i][i] <= 0){
                throw new RuntimeException("Matrix not positive definite");
            }
        }
        return L;
    }

    //consumes lower triangular and upper triangular and vector, returns vector
    //answer
    public static double[] luEvaluate(double[][] L, double[][] U, double[] b){
        int n = b.length;
        double[] x = new double[n];
        double[] y = new double[n];
        // solve Uy = b
        for(int i = 0; i < n; i++){
            y[i] = b[i];
            for(int j = 0; j < i; j++){
                y[i] -= L[i][j] * y[j];
            }
            y[i] /= L[i][i];
        }
        // solve Lx = y
        for(int i = n - 1; i >= 0; i--){
            x[i] = y[i];
            for(int j = i + 1; j < n; j++){
                x[i] -= U[i][j] * x[j];
               
            }
            x[i] /= U[i][i];
        }
        return x;
    }

    public static double[][] makeSymmetric(double[][] A){
        int n = A.length;
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                A[i][j] = A[j][i];
            }
        }
        return A;
    }

    public static double[][] transpose(double[][] A){
        int n = A.length;
        double [][] At = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                At[i][j] = A[j][i];
                At[j][i] = A[i][j];
            }
        }
        return At;
    }

    public static double[][] multiply(double[][] A, double[][] B){
        int n = A.length;
        double sum = 0;
        double[][] C = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    sum += A[i][k] * B[k][j];
                }
                C[i][j] = sum;
                sum = 0;
            }
        }
        return C;
    }

    public static String convertToString(double[][] A){
        String s = "";
        for(double[] i : A){
            for(double j : i){
                s += String.format("%7.2f", j);
            }
            s += "\n";
        }
        return s;
    }

    public static String covertToString(double[] x){
        String s = "";
        for(double i : x){
            s += String.format("%7.2f", i);
        }
        return s;
    }
}