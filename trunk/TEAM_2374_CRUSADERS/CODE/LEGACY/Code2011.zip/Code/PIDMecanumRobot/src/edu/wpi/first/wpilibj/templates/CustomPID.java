/*
 * Last Changed: 4 December 2010
 * Changed: Adding Javadoc
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.SpeedController;

/**
 *This class is an implementation for a PID control loop
 * for a motor. It handles the Encoder and Jaguar interactions.
 * @author wreilly
 */
public class CustomPID {//implements Runnable {


    private double pConstant, iConstant, dConstant;

    private double setPoint;
    //private double prevPWMVal;
    private SpeedController jag;
    /*private int encoderNum;
    private MultipleEncoderAverager multipleAverager;*/
    Encoder encoder;
    private double currentPWMVal;
    private boolean nanPresent;
    private boolean encodersOn;


    /**
     * This function gets the value of the encoder if it is on and increments the
     * current PWM value by the output. If the encoder is off, it passes the
     * setpoint to the PWM value. Finally, the Jaguar is set to the PWM value
     */
    public void update() {
        if(encodersOn){
            double output = getOutputValue();
            //System.out.println("                                                                          Output: " + output);
            if(!Double.isNaN(output)){
                currentPWMVal = currentPWMVal + output;
            }
            else{
                System.out.println("NaNner nanner nanner");
                currentPWMVal = this.getSetPoint();
            }
            //System.out.println("In Encoder On Mode");
        }
        else if(!encodersOn){
            currentPWMVal = this.getSetPoint();
            //System.out.println("In Encoder Off Mode");
        }
        currentPWMVal = this.deadbandModifier(currentPWMVal, 0.0, .05);
        if(currentPWMVal<0){
            currentPWMVal = Math.max(currentPWMVal, -1.0);
        }
        else{
        currentPWMVal = Math.min(currentPWMVal, 1.0);
        }
        //System.out.println("                                         current pwm: " + currentPWMVal);
        jag.set( currentPWMVal);



    }
    /*public CustomPID(){
    this(1,0,0, new Victor(1,1), new Encoder(1,2));
    }*/

    /**
     * Constructor
     * @param p The P constant
     * @param i The I constant
     * @param d The D constant
     * @param jaguar The Jaguar to control
     * @param encode The Encoder to check
     */
    public CustomPID(double p, double i, double d, SpeedController jaguar, Encoder encode){
        this.pConstant = p;
        this.iConstant = i;
        this.dConstant = d;
        this.setPoint = 0.0;
        //this.prevPWMVal = 0.0;
        this.jag = jaguar;
        encoder = encode;
        currentPWMVal = 0.0;
        encodersOn = true;
    }

    /**
     * Gets the D constant
     * @return The D constant
     */
    public double getdConstant() {
        return dConstant;
    }

    /**
     * Sets the D constant
     * @param dConstant Value to set the D constant to
     */
    public void setdConstant(double dConstant) {
        this.dConstant = dConstant;
    }

    /**
     * Gets the I constant
     * @return The I constant
     */
    public double getiConstant() {
        return iConstant;
    }

    /**
     * Sets the I constant
     * @param iConstant Value to set the I constant to
     */
    public void setiConstant(double iConstant) {
        this.iConstant = iConstant;
    }

    /**
     * Gets the P constant
     * @return The P constant
     */
    public double getpConstant() {
        return pConstant;
    }

    /**
     * Sets the P constant
     * @param pConstant Value to set the P constant to
     */
    public void setpConstant(double pConstant) {
        this.pConstant = pConstant;
    }

    /**
     * Gets the set point for the control loop
     * @return The control loop's set point 
     */
    public double getSetPoint() {
        return setPoint;
    }

    /**
     * Sets the setpoint for the control loop.
     * @param setPoint Value to set the control loops' set point
     */
    public void setSetPoint(double setPoint) {
        this.setPoint = setPoint;
    }

    /**
     * Returns the calculated error for the control loop.
     * The error is defined as the difference between the set point
     * and the encoders
     * @return The loop's error
     */
    public double getError(){
        double error = this.setPoint - (this.encoder.getRate())/7500.0;
        //System.out.println("error: " + error);
        return error;
    }

    /**
     * Gets the output value. Currently, it's just the P part
     * @return The output value
     */
    public double getOutputValue(){
        return pConstant * getError();
    }

    /**
     * Gets the current calculated PWM value. Note, this may not be the
     * same as the Jaguar's current value
     * @return The current PWM values
     */
    public double getCurrentPWMVal() {
        return currentPWMVal;
    }

    /**
     * Directly sets the current PWM value. Use setSetPoint and update for a
     * more elegant way to update the current PWM value
     * @see CustomPID#setSetPoint(double) setSetPoint
     * @param currentPWMVal
     */
    public void setCurrentPWMVal(double currentPWMVal) {
        this.currentPWMVal = currentPWMVal;
    }

    /**
     * Helper function to account for a dead band
     * @param stickVal The value to check
     * @param center The center of the dead band
     * @param bandSize The size of the band
     * @return A dead-band adjusted value
     */
    public double deadbandModifier(double stickVal, double center, double bandSize){
        double output = stickVal;
        if(center - bandSize <= stickVal && stickVal<= center + bandSize)
            output = 0;
        return output;
    }

    /**
     * Checks if the encoder is soft-enabled
     * @return If the encoder is on
     */
    public boolean isEncodersOn() {
        return encodersOn;
    }

    /**
     * Sets if the encoders are used or not
     * @param encodersOn
     */
    public void setEncodersOn(boolean encodersOn) {
        this.encodersOn = encodersOn;
    }

    /**
     * Toggles the encoders on and off
     */
    public void switchEncoders(){
        this.encodersOn = !encodersOn;
    }


    
}
