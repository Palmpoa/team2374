/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;

/**
 *
 * @author wreilly
 */
public class MultipleEncoderAverager implements Runnable{

    private double averageFR;
    private double averageFL;
    private double averageRR;
    private double averageRL;

    private Encoder encoderFR;
    private Encoder encoderFL;
    private Encoder encoderRR;
    private Encoder encoderRL;

    private double[] rateValsFR;
    private double[] rateValsFL;
    private double[] rateValsRR;
    private double[] rateValsRL;

    public final int ENCODER_FR = 1;
    public final int ENCODER_FL = 2;
    public final int ENCODER_RR = 3;
    public final int ENCODER_RL = 4;

    /**
     * Keeps track of the four drive encoders' average values
     * @param encode1 Front right encoder
     * @param encode2 Front left encoder
     * @param encode3 Rear right encoder
     * @param encode4 Rear left encoder
     */
    public MultipleEncoderAverager(Encoder encode1, Encoder encode2, Encoder encode3, Encoder encode4){
        encoderFR = encode1;
        encoderFL = encode2;
        encoderRR = encode3;
        encoderRL = encode4;
        rateValsFR = new double[20];
        rateValsFL = new double[20];
        rateValsRR = new double[20];
        rateValsRL = new double[20];


    }

    /**
     * This function is called on a new thread to keep a running average
     */
    public void run() {
        int count = 0;
        while(true){
            if(count > 19){ //The array is length 20. Loop through and overwrite values
                count = 0;
            }
            rateValsFR[count] = encoderFR.getRate();
            rateValsFL[count] = encoderFL.getRate();
            rateValsRR[count] = encoderRR.getRate();
            rateValsRL[count] = encoderRL.getRate();
            calculateAverage(); //Update the averages
            count++;
        }
    }

    /**
     * This calculates the average value of each wheel/encoder's array
     * and stores  it
     */
    public void calculateAverage(){
        double tempSumFR = 0;
        double tempSumFL = 0;
        double tempSumRR = 0;
        double tempSumRL = 0;
        for(int i = 0; i<19; i++){
            tempSumFR += rateValsFR[i];
            tempSumFL += rateValsFL[i];
            tempSumRR += rateValsRR[i];
            tempSumRL += rateValsRL[i];
        }
        this.averageFR = tempSumFR/20.0;
        this.averageFL = tempSumFL/20.0;
        this.averageRR = tempSumRR/20.0;
        this.averageRL = tempSumRL/20.0;
    }

    /**
     * Helper method to get the average vale of an encoder
     * use ENCODER_FL, ENCODER_FR, ENCODER_RL, ENCODER_RR
     * @param encoderNumber ENCODER_FL, ENCODER_FR, ENCODER_RL, or ENCODER_RR
     * @return The The dead band adjusted average value of the specified encoder
     */
    public double getAverageValue(int encoderNumber){
           if(encoderNumber == this.ENCODER_FL)
               return getAverageFL();
           else if (encoderNumber == this.ENCODER_FR)
               return getAverageFR();
           else if(encoderNumber == this.ENCODER_RL)
               return getAverageRL();
           else
               return getAverageRR();
    }

    /**
     * Gets the average rate of the front left encoder
     * @return The The dead band adjusted average rate of the front left encoder
     */
    public double getAverageFL() {
        return deadBand(averageFL/7500.0);
    }

    /**
     * Gets the average rate of the front right encoder
     * @return The The dead band adjusted average rate of the front right encoder
     */
    public double getAverageFR() {
        return deadBand(averageFR/7500.0);
    }
    /**
     * Gets the average rate of the rear left encoder
     * @return The dead band adjusted average rate of the rear left encoder
     */
    public double getAverageRL() {
        return deadBand(averageRL/7500.0);
    }

    /**
     * Gets the average rate of the rear right encoder
     * @return The dead band adjusted average rate of rear right encoder
     */
    public double getAverageRR() {
        return  deadBand(averageRR/7500.0);
    }

    /**
     * Creates a deadband of -.05 to .05
     * @param val The value to adjust
     * @return Dead band adjusted value
     */
    public double deadBand(double val){
        double returnVal = val;
        if(-.05< returnVal && returnVal < .05)
            returnVal = 0.0;
        return returnVal;
    }

    

}































