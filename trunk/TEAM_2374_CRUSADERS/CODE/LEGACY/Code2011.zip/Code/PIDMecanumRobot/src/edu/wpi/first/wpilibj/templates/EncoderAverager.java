/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;

/**
 *
 * @author wreilly
 */
public class EncoderAverager implements Runnable{

    private double average;
    private Encoder encoder;
    private double[] rateVals;

    /**
     * Creates an averager for the specified encoder
     * @param encode
     */
    public EncoderAverager(Encoder encode){
        encoder = encode;
        rateVals = new double[20];
    }

    /**
     * This function is called by the new averaging thread. It updates
     * the rate array with new values and then stores the average of the array
     */
    public void run() {
        int count = 0;
        while(true){
            if(count > 19){
                count = 0;
            }
            rateVals[count] = encoder.getRate();
            calculateAverage();
            count++;
        }
    }

    /**
     * Helper method to compute average of the rate array
     */
    public void calculateAverage(){
        double tempSum = 0;
        for(int i = 0; i<19; i++){
            tempSum += rateVals[i];
        }
        this.average = tempSum/rateVals.length; 
    }

    /**
     * Returns the average rate of the encoder
     * @return
     */
    public double getAverage() {
        return average/7500.0; //Scale the rate to something between -1 and 1
    }

    





}
