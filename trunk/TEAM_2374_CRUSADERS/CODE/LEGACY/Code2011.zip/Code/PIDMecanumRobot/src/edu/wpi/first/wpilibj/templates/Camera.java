/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Servo;
import edu.wpi.first.wpilibj.camera.AxisCamera;

/**
 * This class handles Rufus and his mount.
 * @author jhsuser
 */
public class Camera {

    Servo tilt, rotation; //These servos tilt and rotate Rufus
    AxisCamera rufus; //Hi, My name is Rufus!

    /**
     * Constructor for Rufus
     * @param rotationPort The servo that pans Rufus
     * @param tiltPort The servo that tilts Rufus
     * @param ac The camera to act as Rufus
     */
    public Camera(int rotationPort, int tiltPort, AxisCamera ac){
        this.tilt = new Servo(tiltPort);
        this.rotation = new Servo(rotationPort);
        this.rufus = ac;
    }

    /**
     * Tilts Rufus
     * @param joystickValue The amount of tilt
     */
    public void setTilt(double joystickValue){
        tilt.set(joystickValue*0.5 + 0.5);
    }

    /**
     * Pans Rufus
     * @param joystickValue The amount to pan
     */
    public void setRotation(double joystickValue){
        tilt.set(0.5*joystickValue + 0.5);
    }

    /**
     * Tilts Rufus to the specified angle
     * @param angle The angle to tilt
     */
    public void tiltAngle(double angle){
        tilt.set(angle);
    }

    /**
     * Pans Rufus to the specified angle
     * @param angle The angle to pan
     */
    public void rotationAngle(double angle){
        rotation.set(angle);
    }

}
