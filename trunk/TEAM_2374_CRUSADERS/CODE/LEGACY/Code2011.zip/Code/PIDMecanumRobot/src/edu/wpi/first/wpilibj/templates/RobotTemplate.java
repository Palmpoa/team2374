/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.AnalogChannel;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.DriverStationLCD.Line;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.camera.AxisCamera;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class RobotTemplate extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */

    // Maps the joystick buttons responsible for changing the PID constants.
    private final int STICK_INCREASE_P = 3; // for increasing the P constant.
    private final int STICK_INCREASE_I = 5; // for increasing the I constant.
    private final int STICK_DECREASE_D = 10; // for decreasing the D constant.
    private final int STICK_INCREASE_D = 11; // for increasing the D constant.
    private final int STICK_RESET_GYRO = 6; // for resetting the gyro PID controller.

    private double kScoreThreshold = .01;

    // Variables for the kicker's status
    private boolean isExtended;
    private boolean isLoaded;
    private boolean isLatched;

    private double prevKickerTime;
    private double currentTime;
    private double prevSideDriveTime;
    
    private boolean ultraTripped2;
    private boolean touchTripped;
    private boolean autonomousGoForward;

    private boolean normAxis;
    private boolean prevNormAxis;

    private boolean inTurn;
    private boolean prevInTurn;

    private boolean inEncodeOff;
    private boolean prevInEncodeOff;

    private boolean inTurn2;
    private boolean prevInTurn2;

    private boolean coverBool;
    private boolean prevCoverBool;
    private boolean coverUp;

    boolean touchSensorTrip;
    boolean ultra2SensorTrip;
    boolean ultra3SensorTrip;

    private DriveSystem driveSys;

    private AnalogChannel ultra;
    private AnalogChannel touch;
    private AnalogChannel ultra2;
    private AnalogChannel ultra3; //Created at 4:18

    int touchVal;
    int prevTouchVal;

    private Timer time;

    private Joystick stick;
    private Joystick stick2;


    private AxisCamera rufus;


    /*//Camera tracker;
    Servo cameraTilt, cameraRotation;*/

    Compressor compressor;
    Solenoid latch, retract, extend, cover;

    public RobotTemplate(){

        autonomousGoForward = true;
        this.touchTripped = false;
        this.ultraTripped2 = false;

        touchSensorTrip = false;
        ultra2SensorTrip = false;
        ultra3SensorTrip = false;

        this.isExtended = false;
        this.isLoaded = false;
        this.isLatched = false;

        rufus = AxisCamera.getInstance();

        time = new Timer();
        time.start();
        driveSys = new DriveSystem();

        normAxis = true;
        prevNormAxis = true;

        ultra = new AnalogChannel(1,6);
        touch = new AnalogChannel(1,5);
        ultra2 = new AnalogChannel(1, 7);
        ultra3 = new AnalogChannel(1, 3);

        this.inEncodeOff = true;
        this.prevInEncodeOff = true;
        
        prevInTurn = true;
        inTurn = true;

        prevInTurn2 = true;
        inTurn2 = true;

        coverBool = true;
        prevCoverBool = true;
        coverUp = false;



        //rufus = AxisCamera.getInstance();

        compressor = new Compressor(9,1); //Digital IO Port 9, Relay 1
        compressor.start();


        retract = new Solenoid(4);
        extend = new Solenoid(5);
        latch = new Solenoid(6);
        cover = new Solenoid(7);



        stick = new Joystick(2);

        stick2 = new Joystick(1);

        //tracker = new Camera(7,6, rufus);
        //cameraTilt = new Servo(6);
        //cameraRotation = new Servo(7);

        getWatchdog().setEnabled(true);
        getWatchdog().setExpiration(1);
    }
    public void autonomous() {
        /*driveSys.frontLeftPID.setEncodersOn(false);
        driveSys.frontRightPID.setEncodersOn(false);
        driveSys.rearLeftPID.setEncodersOn(false);
        driveSys.rearRightPID.setEncodersOn(false);*/
        //driveSys.gyroPID.disable();
        isExtended = isLoaded = isLatched = false;
        touchTripped = ultra2SensorTrip = ultraTripped2= false;
        driveSys.setNormalAxis(true);
        while(isAutonomous()){
            currentTime = time.get();
            double startTime = 0;
            cover.set(true);
            if(ultraTripped2)
                ultraTripped2 = true;  //once it has been tripped, we want it to stay like that forver
            else
                ultraTripped2 = ultraTripped2();
            if(touchTripped)          //after first hit, we are very unlikely to trip this sensor again
                touchTripped = true;
            else
                touchTripped = touchTripped();

            if(!isExtended && !isLoaded && !isLatched){
                prevKickerTime = time.get();
                latch.set(true);
                extend.set(true);
                retract.set(false);
                isExtended = true;
                System.out.println("Whose extended?!?! I am!");     // That's what she said.
            }
            else if(isExtended && !isLoaded && currentTime-prevKickerTime>1.5 && !isLatched){
                latch.set(false);
                prevKickerTime = time.get();
                isLatched = true;
                System.out.println("Locked and ready to fire - pull back to begin");

            }
            else if(isExtended && !isLoaded && isLatched && currentTime-prevKickerTime>.25){
                retract.set(true);
                extend.set(false);
                prevKickerTime = time.get();
                isLoaded = true;
                isExtended = false;
                System.out.println("I tried to retract, did it work?");
            }
            else{
                System.out.println("Pneumatics and booleans do not mix");
            }

            //THIS CODE IS NOT GUARANTEED TO WORK - CHRIS AND ZUHAIR, BUT IT KINDA DOES

            double yDrive=0;
            double xDrive = 0.0;
            if(!ultraTripped2){
                yDrive = .3;
                xDrive = .07;
                getWatchdog().feed();
                //driveSys.update();
                System.out.println("ultra2 is not tripped");
            }
            else if(ultraTripped2 ){ //&& isExtended && isLoaded && isLatched
                ultra2SensorTrip = true;
                //isExtended = isLoaded = isLatched = false;
                //prevKickerTime = time.get();
                yDrive = 0.0;
                xDrive = 0.0;
                System.out.println("Fired!");
                
            }
            /*else if(ultraTripped2 && !isLoaded){ //&& !isExtended && !isLatched){
            System.out.println("Not ready but tripped!");
            yDrive = -.3;
            }
            else{
            System.out.println("I'm going to stop and ponder how I got here ");
            }*/
            if(ultra2SensorTrip) {
                latch.set(true);
                System.out.println("Fired!"); }
            if(ultra2SensorTrip && currentTime-startTime> 10){
                yDrive = 0;
                System.out.println("Ultra2SensorTrip and 30 seconds");

            }
            driveSys.setStickY(yDrive);
            driveSys.setStickZ(0);
            driveSys.setStickX(xDrive);
            driveSys.update();
            System.out.print(driveSys.stickX+"                                  ");
            System.out.print(driveSys.stickY+"                                  ");
            System.out.println(driveSys.stickZ+"                                ");
            System.out.print("Loaded "+isLoaded+"                               ");
            System.out.print("Extended "+isExtended+"                            ");
            System.out.print("Latched "+isLatched+"                            ");
            System.out.println("Ultra 2: "+this.ultra2.getAverageValue());
            getWatchdog().feed();
        }

    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {
        // Initialize the drive system.
        // Inform the PID controllers that they are working with encoders enabled.
        driveSys.frontLeftPID.setEncodersOn(true);
        driveSys.frontRightPID.setEncodersOn(true);
        driveSys.rearLeftPID.setEncodersOn(true);
        driveSys.rearRightPID.setEncodersOn(true);
        driveSys.gyroPID.enable();

        // Begin the main OperatorControl loop
        while(isOperatorControl()){

            // The x, y, and z values from the joystick.
            double yVal = getY();
            double xVal = getX();
            double zVal = getZ();

            // Increment the P constant if the user so desires.
            if(stick2.getRawButton(STICK_INCREASE_P)){
            driveSys.getGyroPID().setPID(driveSys.getGyroPID().getP()+ .005,
                    driveSys.getGyroPID().getI(),driveSys.getGyroPID().getD());
            }

            // TODO: WHAT THE FUCK IS THIS FOR???
            if(stick2.getTrigger()){
                if(ultraTripped2()){
                    this.ultra2SensorTrip = true;
                }
                /*if(ultraTripped23()){
                    this.ultra3SensorTrip = true;
                }*/
                if(ultra2SensorTrip)// || ultra3SensorTrip)
                    latch.set(true);
                

            }
            else{
                ultra2SensorTrip = false;
                ultra3SensorTrip = false;
            }

            if(stick2.getRawButton(2)){
                if(touchTripped()){
                    this.touchSensorTrip = true;
                }
                if(touchSensorTrip)
                    latch.set(true);
            }

            else{
                touchSensorTrip = false;
            }
            // end of todo.

            if(stick2.getRawButton(4)){
                driveSys.getGyroPID().setPID(driveSys.getGyroPID().getP()+.005,
                    driveSys.getGyroPID().getI(),driveSys.getGyroPID().getD());
            }

            if(stick2.getRawButton(STICK_INCREASE_I)){
                driveSys.getGyroPID().setPID(driveSys.getGyroPID().getP(),
                    driveSys.getGyroPID().getI()+.005,driveSys.getGyroPID().getD());
            }

            if(stick2.getRawButton(STICK_DECREASE_D)){
                driveSys.getGyroPID().setPID(driveSys.getGyroPID().getP(),
                    driveSys.getGyroPID().getI(),driveSys.getGyroPID().getD() -.005);
            }

            if(stick2.getRawButton(STICK_INCREASE_D)){
                driveSys.getGyroPID().setPID(driveSys.getGyroPID().getP(),
                    driveSys.getGyroPID().getI()+.005,driveSys.getGyroPID().getD() + .005);
            }

            if(stick.getRawButton(STICK_RESET_GYRO)){
                driveSys.getGyro().reset();
            }

            if(stick2.getRawButton(7) && !stick2.getRawButton(6)){ //kicker grabber logic
            retract.set(false);
            extend.set(true);
            }
            else if(!stick2.getRawButton(7) && stick2.getRawButton(6)){
            retract.set(true);
            extend.set(false);
            }

            if(stick2.getRawButton(9)){
                this.coverBool = false;
                this.prevCoverBool = false;
            }
            else{
                this.coverBool = true;
                        if(!(coverBool && prevCoverBool)){
                            coverUp = !coverUp;
                        }
                this.prevCoverBool = true;
            }
            
            if(coverUp)
                cover.set(true);
            else
                cover.set(false);

            if(stick2.getRawButton(8)){  //kicker releaser
                latch.set(true);
            }
            else if(!(this.ultra2SensorTrip || this.touchSensorTrip || this.ultra3SensorTrip)){
                latch.set(false);
            }


            
           

            if(stick.getRawButton(5)){
                this.inEncodeOff = false;
                this.prevInEncodeOff = false;
            }
            else{
                this.inEncodeOff = true;
                if(!(inEncodeOff && prevInEncodeOff)){
                    driveSys.switchEncoders();
                }
                this.prevInEncodeOff = true;
            }


            if(stick.getRawButton(8)){
                inTurn = false;
                prevInTurn = false;
                driveSys.getGyroPID().setOutputRange(-.3, .3);
                driveSys.getGyroPID().setSetpoint(-95.0);
                driveSys.setInAutoTurn(true);
            }
            else{
                inTurn = true;
                if(!(prevInTurn && inTurn)){
                    driveSys.getGyro().reset();
                    driveSys.getGyroPID().setSetpoint(0.0);
                    driveSys.getGyroPID().setOutputRange(-.3, .3);
                    driveSys.switchAxis();
                    driveSys.setInAutoTurn(false);
                }
                prevInTurn = true;

            }

            if(stick.getRawButton(7)){
                inTurn2 = false;
                prevInTurn2 = false;
                driveSys.getGyroPID().setOutputRange(-.3, .3);
                driveSys.getGyroPID().setSetpoint(90.0);
                driveSys.setInAutoTurn(true);
            }
            else{
                inTurn2 = true;                
                if(!(prevInTurn2 && inTurn2)){
                    driveSys.getGyro().reset();
                    driveSys.getGyroPID().setSetpoint(0.0);
                    driveSys.getGyroPID().setOutputRange(-.3, .3);
                    driveSys.switchAxis();
                    driveSys.setInAutoTurn(false);
                }
                prevInTurn2 = true;

            }

            if(stick.getRawButton(4)){   //switch axis button
                normAxis = false;
                prevNormAxis = false;
            }
            else{
                normAxis = true;
                if(!(prevNormAxis && normAxis)){
                    driveSys.switchAxis();
                }
                prevNormAxis = true;

            }

            if(stick.getRawButton(3)){           //lock to x-axis
                this.driveSys.setStickX(xVal);
                this.driveSys.setStickY(0.0);
                this.driveSys.setStickZ(0.0);
            }

            else if(stick.getRawButton(2)){ //lock to y-axis
                this.driveSys.setStickX(0.0);
                this.driveSys.setStickY(yVal);
                this.driveSys.setStickZ(0.0);
            }
            else{                          //normal (if you can call it that)
                this.driveSys.setStickY(yVal);
                this.driveSys.setStickX(xVal);
                this.driveSys.setStickZ(zVal/3);

            }


            //System.out.println(" zSetPt: " + driveSys.getGyroPID().getSetpoint());
            //System.out.print("Touch: " + touch.getAverageValue());
            //System.out.print("                        Ultra2: "+ ultra2.getAverageValue());
            //System.out.println("                                                                Ultra3: " + ultra3.getAverageValue());
            getWatchdog().feed();
            driveSys.update();
            updateDashboard();

            getWatchdog().feed();
        }

    }

    public void updateDashboard(){
        DriverStationLCD lcd = DriverStationLCD.getInstance();
        CustomPID FL= driveSys.getFrontLeftPID();
        CustomPID FR = driveSys.getFrontRightPID();
        CustomPID RR = driveSys.getRearRightPID();
        CustomPID RL = driveSys.getRearLeftPID();
        /*lcd.println(Line.kUser2, 1, "FR: " + round(FR.getCurrentPWMVal()) +
                "   axis: " + driveSys.isNormalAxis());
        lcd.println(Line.kUser3, 1, "latch: " + isLatched());
        lcd.println(Line.kUser4, 1, "  extended" + isExtended() );
        lcd.println(Line.kUser5, 1, " ultra3: " + round(ultra3.getAverageValue()) );
        lcd.println(Line.kMain6, 1,"ultra2: " + round(ultra2.getAverageValue()) );*/

        lcd.println(Line.kUser2, 1, "P: "+FL.getpConstant());
        lcd.println(Line.kUser3, 1, "I: "+FL.getiConstant());
        lcd.println(Line.kUser4, 1, "D: "+FL.getdConstant());
        lcd.updateLCD();

        }

    public double getY(){
        return deadBand(1.0 * stick.getY());  //axis reversal for gamepad controller

    }

    public double getZ(){
        return deadBand(-1.0*stick.getZ());
    }

    public double getX(){
        return  deadBand(1.0*stick.getX());
    }
    public double deadBand(double d){

        double val = d;
        if(-.05 < val && val < .05)
            val = 0.0;
        return val;
    }

    public double round(double d){
    d*=100;
    d = Math.floor(d+.5);
    d/=100;
    return d;
    }

    public boolean ultraTripped(){
        return ultra.getAverageValue()<=17;
    }
    public boolean ultraTripped2(){
        return ultra2.getAverageValue()<=14;
    }
    public boolean ultraTripped3(){
        return ultra3.getAverageValue()<=23;
    }

    public boolean touchTripped(){
        return touch.getAverageValue() > 15;
    }
    
    public boolean isLatched(){
        return !latch.get();
    }
    
    public boolean isExtended(){
        return extend.get();
    }


}
