/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.PIDController;
import edu.wpi.first.wpilibj.Timer;

/**
 *
 * @author wreilly
 */
public class DriveSystem {

    // Definitions of the PID constants for the gyro PID controller
    private final double GYRO_P = .12999;
    private final double GYRO_I = 0.43000;
    private final double GYRO_D = 0.46555;

    SpeedController rearLeftMotor;
    SpeedController frontLeftMotor;
    SpeedController rearRightMotor;
    SpeedController frontRightMotor;
    
    Encoder rearLeftEncoder;
    Encoder rearRightEncoder;
    Encoder frontRightEncoder;
    Encoder frontLeftEncoder;

    Thread multipleEncoderThread;
    
    MultipleEncoderAverager multipleAverager;

    private boolean encodersAreOn;

    private boolean normalAxis;

    private boolean inAutoTurn;

    ZClass zControl;
    PIDController gyroPID;
    Gyro gyro;


    CustomPID rearLeftPID;
    CustomPID frontLeftPID;
    CustomPID rearRightPID;
    CustomPID frontRightPID;
    
    Timer time;

    private final int PURE_MECANUM = 0;
    private final int AXIS_MECANUM = 1;
    private final int NON_PID_MECANUM = 2;

    private int driveMode;



    double stickX, stickY, stickZ;
    
    private final double kP = .1 , kI = 0.0, kD = 0.0;

    /**
     * DriveSystem default constructor.
     * Initializes drive PIDS with motors and encoders, Gyroscope PID,
     * and enables a pure mecanum PID
     */
    public DriveSystem(){

        normalAxis = true; //Robot facing away from the driver

        encodersAreOn = true; //Program does read from the encoders

        inAutoTurn = false; //The robot is not currently rotating +/- 90 degrees

        driveMode = this.PURE_MECANUM; //All mecanum, all the time

        gyro = new Gyro(1,1); //Gyroscope in Analog 1, 1
        gyro.setSensitivity(0.007); //Need to set the sensitivity to make it work

        zControl = new ZClass(); //A place for the Gyro PID to write to
        gyroPID = new PIDController(GYRO_P, GYRO_I, GYRO_D, //Set up the gyro correction
                gyro, zControl);
        gyroPID.setOutputRange(-.3, .3); //Restricts the z to between -.3 and .3
        gyroPID.enable(); //Begin the PID

        //Start at rest
        this.stickX = 0;
        this.stickY = 0;
        this.stickZ = 0;

        //Set up the Jaguars for all the motors
        this.rearLeftMotor = new Jaguar(1);
        this.rearRightMotor = new Jaguar(3);
        this.frontRightMotor = new Jaguar(2);
        this.frontLeftMotor = new Jaguar(4);

        //Set up the econders for each motor
        this.rearLeftEncoder = new Encoder(3,4, true);
        this.rearRightEncoder = new Encoder(1,2, false);
        this.frontRightEncoder = new Encoder(7,8, true);
        this.frontLeftEncoder = new Encoder(5,6, true);

        //Tell the encoders to start
        this.rearLeftEncoder.start();
        this.rearRightEncoder.start();
        this.frontLeftEncoder.start();
        this.frontRightEncoder.start();
        /*multipleAverager = new MultipleEncoderAverager(this.frontRightEncoder, this.frontLeftEncoder,
        this.rearRightEncoder, this.rearLeftEncoder);
        this.multipleEncoderThread = new Thread(this.multipleAverager);
        this.multipleEncoderThread.start();*/

        //Create the PIDS for each wheel with a wheel and encoder pairing
        this.frontLeftPID = new CustomPID(kP, kI, kD, this.frontLeftMotor, this.frontLeftEncoder);
        this.rearLeftPID = new CustomPID(kP, kI, kD, this.rearLeftMotor, this.rearLeftEncoder);
        this.rearRightPID = new CustomPID(kP, kI, kD, this.rearRightMotor, this.rearRightEncoder);
        this.frontRightPID = new CustomPID(kP, kI, kD, this.frontRightMotor, this.frontRightEncoder);

        

    }

    //Test Frame Method (alternative to threading)

    /**
     * Uses an (x,y,z) and turns it into (strafe,speed,turn) which
     * turn into PWM values for each wheel and passes them to the
     * respective PID loop. Also uses the gyro for driving correction
     * @param x Relative amount of strafe
     * @param y Relative amount of speed
     * @param z Relative amount of turn
     */
    public void mecanumDriveSet(double x, double y, double z){
        double strafe;
        double speed;
        double turn;

        //Hotdog style
        if(!isNormalAxis()){

            strafe = deadbandModifier(-1.0*x, 0.0, .05); //side motion STRAFE IS Y AXIS FOR THIS YEARS ROBOT
            speed = deadbandModifier(y, 0.0, .05);  //forward/backward motion
            turn = deadbandModifier(z, 0.0, .05);   //turning motion
        }
        //Hamburger style
        else{
            strafe = deadbandModifier(y, 0.0, .05); //side motion STRAFE IS Y AXIS FOR THIS YEARS ROBOT
            speed = deadbandModifier(x, 0.0, .05);  //forward/backward motion
            turn = deadbandModifier(z, 0.0, .05);   //turning motion
        }

        //If the robot is supposed to be going straight and is not turning or strafing...
        if(turn==0.0 && (isInAutoTurn() || strafe!=0)){  //&& (isInAutoTurn() || (strafe!=0.0 && speed!=0.0))   // && strafe!=0.0 && speed!=0.0
            turn = this.zControl.getZ(); //... autocorrect
        }
        else
            gyro.reset(); //reset the gyro so the new direction is zero

        /*System.out.println("Strafe:  " + strafe + "    Speed: " + speed + "     " + turn +
        "   FR: " + frontRightPID.getCurrentPWMVal() + "    FL: " + frontLeftPID.getCurrentPWMVal()+
        "   RL: " + rearLeftPID.getCurrentPWMVal() + "   RR: " + rearRightPID.getCurrentPWMVal());*/

        //A division factor for scaling mecanum values
        double divisionFactor = pwmScaleFactor(strafe, speed, turn);
        //System.out.print(" factor: " + divisionFactor);
        //System.out.print("   Speed:" + speed + "  strafe: " + strafe + " turn: " + turn);

        double pwmRearLeft;
        double pwmRearRight;
        double pwmFrontLeft;
        double pwmFrontRight;

       //Mecanum values scaled down to PWM range values
        pwmRearLeft = ((speed - strafe - turn)/divisionFactor);
        pwmRearRight = ((speed + strafe + turn)/divisionFactor);
        pwmFrontLeft = (speed + strafe - turn)/divisionFactor;
        pwmFrontRight = (speed - strafe + turn)/divisionFactor;
        
        /*else{
        pwmRearLeft = ((speed - strafe - turn));
        pwmRearRight = ((speed + strafe + turn));
        pwmFrontLeft = (speed + strafe - turn);
        pwmFrontRight = (speed - strafe + turn);

        double max = Math.max(pwmRearLeft, Math.max(pwmRearRight, Math.max(pwmFrontLeft, pwmFrontRight)));

        pwmRearLeft = pwmRearLeft/max;
        pwmRearRight = pwmRearRight/max;
        pwmFrontRight = pwmFrontRight/max;
        pwmFrontLeft = pwmFrontLeft/max;
        }*/

       // System.out.println(" pwmRearLeft: " + pwmRearLeft + " pwmFrontLeft: " + pwmFrontLeft + " pwmRearRight:" + pwmRearRight);


        this.frontLeftPID.setSetPoint(pwmFrontLeft);
        this.frontRightPID.setSetPoint(pwmFrontRight);
        this.rearLeftPID.setSetPoint(pwmRearLeft);
        this.rearRightPID.setSetPoint(pwmRearRight);

        this.frontLeftPID.update();
        this.rearLeftPID.update();
        this.frontRightPID.update();
        this.rearRightPID.update();

    }

    

 
    /**
     * Updates the drive system with the stored stick variables.
     * Currently, it only implements mecanum drive
     */
    public void update(){
        double x = this.stickX;
        double y = this.stickY;
        double z = this.stickZ;
        if(driveMode == this.PURE_MECANUM){
            mecanumDriveSet(x, y, z);
        }
 
    }
    
    /**
     * Helper function to account for a dead band
     * @param stickVal The value to check
     * @param center The center of the dead band
     * @param bandSize The size of the band
     * @return A dead-band adjusted value
     */
    public double deadbandModifier(double stickVal, double center, double bandSize){
        double output = stickVal;
        if(center - bandSize <= stickVal && stickVal<= center + bandSize)
            output = 0;
        return output;
    }

    /**
     * Clamps an input into PWM safe values
     * @param inp The value to clamp
     * @return A clamped number between -1 and 1
     */
    public double pwm_limit ( double inp)
    {
	if(inp<-1)
		inp = -1;
	if (inp>1)
		inp = 1;
	//inp = inp+1;

	return inp;
    }

    /**
     * Helper function to get the PWM scale factor to help with mecanum drive
     * @param strafe Desired strafe value
     * @param speed Desired speed value
     * @param turn Desired turn value
     * @return A factor for PWM
     */
    public double pwmScaleFactor(double strafe, double speed, double turn){
        double factor = 0;
        if(strafe != 0)
            factor++;
        if(speed!= 0)
            factor++;
        if(turn!=0)
            factor++;
        if(factor==0)
            factor = 1;
        return factor;

    }

    /**
     * Gets the DriveSystem's MultipleEncoderAverager
     * @return The drive system's MultipleEncoderAverager
     */
    public MultipleEncoderAverager getMultipleAverager() {
        return multipleAverager;
    }

    /**
     * Gets the front left wheel's PID
     * @return Front left wheel's PID
     */
    public CustomPID getFrontLeftPID() {
        return frontLeftPID;
    }

    /**
     * Gets the rear left wheel's PID
     * @return Rear left wheel's PID
    */
    public CustomPID getRearLeftPID() {
        return rearLeftPID;
    }

    /**
    * Gets the front right wheel's PID
    * @return Front right wheel's PID
    */
    public CustomPID getFrontRightPID() {
        return frontRightPID;
    }
    
    /**
     * Gets the rear right wheel's PID
     * @return Rear right wheel's PID
     */
    public CustomPID getRearRightPID() {
        return rearRightPID;
    }


    /**
     * Gets the stored x value of the stick
     * @return Stick's x value
     */
    public double getStickX() {
        System.out.print(stickX+"               ");
        return stickX;
    }

    /**
     * Sets the stored x value of the stick. Doesn't
     * actually do anything. Call the
     * {@link #update() update} method after this to update the robot.
     * @param stickX The value to set the x value to
     */
    public void setStickX(double stickX) {
        this.stickX = stickX;
    }

    /**
     * Gets the stored y value of the stick
     * @return The stored y value of the stick
     */
    public double getStickY() {
        System.out.println(stickY+"             ");
        return stickY;
    }

    /**
     * Sets the stored y value of the stick. Doesn't
     * actually do anything. Call the
     * {@link #update() update} method after this to update the robot.
     * @param stickY The value to set y value to
     */
    public void setStickY(double stickY) {
        this.stickY = stickY;
    }

    /**
     * Gets the stored z value of the stick. 
     * @return The stored z value of the stick.
     */
    public double getStickZ() {
        System.out.println(stickZ+"             ");
        return stickZ;
    }

    /**
     * Sets the stored z value of the stick. Doesn't
     * actually do anything to the robot. Call the
     * {@link #update() update} method after this to update the robot.
     * @param stickZ
     */
    public void setStickZ(double stickZ) {
        this.stickZ = stickZ;
    }

    /**
     * Gets the Drive System's drive correction gyroscope
     * @return Drive system's gyroscope
     */
    public Gyro getGyro() {
        return gyro;
    }

    /**
     * Gets the drive correction PID control loop
     * @return The Gyroscope PID
     */
    public PIDController getGyroPID() {
        return gyroPID;
    }

    /**
     * Toggles the drive axis. Useful when driving towards you.
     */
    public void switchAxis(){
        normalAxis = !normalAxis;
    }

    /**
     * Checks if the normal drive axis is in use
     * @return If normal drive axis.
     */
    public boolean isNormalAxis() {
        return normalAxis;
    }

    /**
     * Manually set the axis between normal and inverted.
     * @param normalAxis
     */
    public void setNormalAxis(boolean normalAxis) {
        this.normalAxis = normalAxis;
    }

    /**
     * Returns if the robot is automatically rotating
     * @return
     */
    public boolean isInAutoTurn() {
        return inAutoTurn;
    }

    /**
     * Whether or not to auto turn.
     * @param inAutoTurn Whether or not to turn
     */
    public void setInAutoTurn(boolean inAutoTurn) {
        this.inAutoTurn = inAutoTurn;
    }

    /**
     * Turns the encoders "off" (stops checking them). Essentially
     * turns off PID.
     */
    public void switchEncoders(){
        this.frontLeftPID.switchEncoders();
        this.frontRightPID.switchEncoders();
        this.rearRightPID.switchEncoders();
        this.rearLeftPID.switchEncoders();
        encodersAreOn = !encodersAreOn;
    }



}

