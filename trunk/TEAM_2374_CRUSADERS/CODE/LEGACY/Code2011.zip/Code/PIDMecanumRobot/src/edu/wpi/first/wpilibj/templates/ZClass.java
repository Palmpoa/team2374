/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.PIDOutput;

/**
 *
 * @author jhsuser
 */
public class ZClass implements PIDOutput{

    private double z; //The z value for the mecanum drive.

    /**
     * Start off with no Z
     */
    public ZClass(){
        z = 0.0;
    }

    /**
     * This will be used in conjunction with the Gyroscope PID
     * @param output How much z is needed for gyroscope correction
     */
    public void pidWrite(double output){
        z = output;
    }

    /**
     * Gets the calculated z value
     * @return Z value for the mecanum drive
     */
    public double getZ(){
        return z;
    }
}
