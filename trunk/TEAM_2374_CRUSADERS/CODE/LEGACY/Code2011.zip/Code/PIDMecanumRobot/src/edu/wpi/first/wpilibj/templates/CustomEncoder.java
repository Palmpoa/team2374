/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Timer;

/**
 * This is a CustomEncoder that returns values at a slower rate
 * @author wreilly
 */
public class CustomEncoder extends Encoder {

    Timer time;

    /**
     * Constructor
     * @param slot The slot the Encoder is plugged in
     * @param channel The channel the Encoder is plugged into
     * @param reverseDirection Whether or not the Encoder should reverse direction
     * @param timer A timer to keep track of the update rate
     */
    public CustomEncoder(int slot, int channel, boolean reverseDirection, Timer timer){
        super(slot, channel, reverseDirection);
        time = timer;
    }

    /**
     * Gets the average rate of the encoder over .025 seconds.
     * (i.e. the rpm of a motor).
     * @return
     */
    public double getRate(){
        double startTime = time.get(), currentTime = time.get(), sum = 0;
        int count = 0;

        while(currentTime - startTime < .025){
            sum+= super.getRate();
            count++;
            currentTime = time.get();
        }

        return sum/count;

    }
}
