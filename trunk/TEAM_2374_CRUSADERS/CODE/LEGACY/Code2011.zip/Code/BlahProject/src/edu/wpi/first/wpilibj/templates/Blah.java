/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SimpleRobot;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Blah extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    public void autonomous() {
        
    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {
        Encoder blah = new Encoder(7,8,false,EncodingType.k2X);
        //blah.setDistancePerPulse(6.0*Math.PI / 1440); //for an omni wheel
        blah.start();
        Jaguar jag = new Jaguar(1);
        DriverStationLCD lcd = DriverStationLCD.getInstance();
        Joystick stick = new Joystick(1);
        double max = Double.NEGATIVE_INFINITY;
        while(isOperatorControl()){
            jag.set(stick.getY());
            double rate = blah.getDistance();
            if(rate > max) max = rate;
            lcd.println(DriverStationLCD.Line.kMain6, 1, "Encoder "+rate+"");
            lcd.println(DriverStationLCD.Line.kUser2, 1, "Max: "+max);
            lcd.updateLCD();
        }
    }
}
