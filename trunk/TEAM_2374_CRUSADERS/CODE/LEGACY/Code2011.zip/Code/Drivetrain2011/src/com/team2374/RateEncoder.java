/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import edu.wpi.first.wpilibj.CounterBase;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.PIDSource;

/**
 *
 * @author robotics
 */
public class RateEncoder extends Encoder implements PIDSource {

    private double[] encoderReadings = new double[20];
    int index = 0; 

    public RateEncoder(int encoderPort1, int encoderPort2, boolean reverseDirection, CounterBase.EncodingType type){
        super(encoderPort1,encoderPort2, reverseDirection, type);
        for(int i=0; i<encoderReadings.length; i++){
            encoderReadings[i] = -1;
        }
    }

    public void update(){
        double reading = getCurrentReading();
        encoderReadings[index%encoderReadings.length] = reading;
        index++;
    }

    public double pidGet() {
        //return readingsAverage();
        return getCurrentReading();
    }

    private double readingsAverage() {
        double sum = 0;
        for(int i=0; i<encoderReadings.length;i++){
            if(encoderReadings[i] != -1) sum += encoderReadings[i];
        }
        return sum;
    }

    public double getCurrentReading(){
        return super.getRate();
    }
    public double getLastReading(){
        return encoderReadings[index-1];
    }

}
