/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import edu.wpi.first.wpilibj.Solenoid;

/**
 *
 * @author robotics
 */
public class Drivetrain {


    private Wheel leftWheel, rightWheel;

    private Solenoid lowGear, highGear;

    public Drivetrain(){
        rightWheel = new Wheel(3,4,4,6); //No PWM on 7
        leftWheel = new Wheel(5,6,5,7);

        lowGear = new Solenoid(1);
        highGear = new Solenoid(2);

        setLowGear();
    }

    //Tank drive right now
    public void update(double stick1Y, double stick2Y){        
        //leftWheel.setTargetSpeed(deadBandModifier(stick1Y)*Wheel.MAX_ENCODER_RATE);
        //rightWheel.set(deadBandModifier(temp2)); //Currently there is no right wheel
        leftWheel.set(deadBandModifier(stick1Y));
        rightWheel.set(-deadBandModifier(stick2Y));
    }

        /**
     * Accounts a deadband for a value
     * @param input The value to adjust
     * @return A deadband adjusted value
     */
    public double deadBandModifier(double input){
        if(Math.abs(input)<= Wheel.DEADBAND_SIZE) return 0;
        return input;
    }

    public Wheel getRightWheel(){ return rightWheel; }
    public Wheel getLeftWheel() { return leftWheel; }

    public void setLowGear(){
        lowGear.set(true);
        highGear.set(false);
    }
    public void setHighGear(){
        lowGear.set(false);
        highGear.set(true);
    }
    public void shift(){
        lowGear.set(!lowGear.get());
        highGear.set(!highGear.get());
    }
}
