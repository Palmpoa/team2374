/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package com.team2374;


import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SimpleRobot;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    Drivetrain drivetrain;
    Compressor compressor;

    public Robot(){
        drivetrain = new Drivetrain();
        compressor = new Compressor(13,1);
    }
    
    public void autonomous() {
        
    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {
        Joystick driveStick = new Joystick(1);
        DriverStationLCD lcd = DriverStationLCD.getInstance();
        compressor.start();
        while(isOperatorControl()){

            /*RateEncoder encoder = drivetrain.getLeftWheel().getEncoder();

            drivetrain.update(driveStick.getRawAxis(2), driveStick.getRawAxis(4));
            lcd.println(Line.kUser3, 1, "Encoder: "+encoder.getRate());

            if(driveStick.getRawButton(4)) Wheel.kP += 0.001;
            if(driveStick.getRawButton(2)) Wheel.kP -= 0.001;
            lcd.println(Line.kUser4, 1, "P Constant: "+Wheel.kP);

            lcd.updateLCD();*/

            drivetrain.update(driveStick.getRawAxis(2),driveStick.getRawAxis(4));
            if(driveStick.getRawButton(6)) drivetrain.setHighGear();
            else drivetrain.setLowGear();

        }
    }
}