/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.PIDSource;

/**
 *
 * @author wreilly
 */
public class PIDEncoder implements Runnable, PIDSource{

    private double average;
    private Encoder encoder;
    private double[] rateVals;
    private final static double ENCODER_RATE = 7500.0;

    public PIDEncoder(Encoder encode){
        encoder = encode;
        rateVals = new double[20];
    }

    public void run() {
        int count = 0;
        while(true){
            if(count > 19){
                count = 0;
            }
            rateVals[count] = encoder.getRate();
            calculateAverage();
            count++;
        }
    }

    public void calculateAverage(){
        double tempSum = 0;
        for(int i = 0; i<19; i++){
            tempSum += rateVals[i];
        }
        this.average = tempSum/20.0;
    }

    public double getAverage() {
        return average/ENCODER_RATE;
    }

    public double pidGet() {
        return getAverage();
    }
}