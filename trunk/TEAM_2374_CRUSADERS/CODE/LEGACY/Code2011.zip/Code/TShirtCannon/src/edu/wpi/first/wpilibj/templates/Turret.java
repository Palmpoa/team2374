/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.AnalogChannel;
import edu.wpi.first.wpilibj.PIDController;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.Victor;

/**
 *
 * @author jhsuser
 */
public class Turret {
    //These are used by the default constructor to identify the ports used by each
    //part of our beautiful system.
    private static final int DEFAULT_MOTOR_PORT_ROTATION = 2; //Yaw
    private static final int DEFAULT_MOTOR_PORT_TILT = 1; //Pitch
    private static final int DEFAULT_INPUT_PORT_POTENTIOMETER = 1;
    private static final int DEFAULT_OUTPUT_PORT_FIRE = 1;

    //Default variables for the PID controller
    private static final double DEFAULT_P_CONSTANT = 0.5;
    private static final double DEFAULT_I_CONSTANT = 0.5;
    private static final double DEFAULT_D_CONSTANT = 0.5;

    //Default wait time between opening and closing
    private static final long DEFAULT_WAIT_TIME_MS = 1000;

    //instantiation of non-public data fields of the turret object
    private boolean firing; //determines whether the cannon is currently in a firing cycle. 0 indicates ready to fire, 1 indicates any other.
    
    //instantiation of inputs and outputs
    private AnalogChannel pot;
    private SpeedController turretRotation;
    private SpeedController turretTilt;
    private PIDController turretPID;
    private Relay fire;

    private long time;

    public Turret(){
        this(DEFAULT_MOTOR_PORT_ROTATION,DEFAULT_MOTOR_PORT_TILT,DEFAULT_INPUT_PORT_POTENTIOMETER,
                DEFAULT_OUTPUT_PORT_FIRE);
    }
    public Turret(int motorPortRotation, int motorPortTilt, int potPort,int relayPort){
        turretRotation = new Victor(motorPortRotation);
        turretTilt = new Victor(motorPortTilt);
        fire = new Relay(relayPort);
        //pot = new AnalogChannel(potPort);

        /*turretPID = new PIDController(DEFAULT_P_CONSTANT,DEFAULT_I_CONSTANT,
                DEFAULT_D_CONSTANT, pot, turretRotation);*/

        time = DEFAULT_WAIT_TIME_MS; //milliseconds
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        if(time >= 0) this.time = time;
    }

    public void update(double x, double y){
        this.turretRotation.set(this.deadbandModifier(x));
        this.turretTilt.set(this.deadbandModifier(y));
    }

    public Relay getFiringRelay(){ return this.fire; }

    public double deadbandModifier(double x){
        if(Math.abs(x)<=0.05) return 0;
        return x;
    }

    public void fire(){
        if(!firing){
            firing = true;
            new Runnable(){
                public void run(){
                    fire.set(Relay.Value.kOn);
                    try {Thread.sleep(time);}
                    catch (InterruptedException ex) {/*
                        (\_/)
                        (=-.-)
                        C(")(")
                     */}
                    fire.set(Relay.Value.kOff);
                    firing = false;
                }
            }.run();
        }
    }
}