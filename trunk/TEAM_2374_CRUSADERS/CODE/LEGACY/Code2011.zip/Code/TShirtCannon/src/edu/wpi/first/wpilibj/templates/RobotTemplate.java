/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.AnalogChannel;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStationEnhancedIO;
import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.PIDController;
import edu.wpi.first.wpilibj.Relay.Value;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.camera.AxisCamera;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class RobotTemplate extends SimpleRobot {
    private static final double DEAD_ZONE = .05;

    private Drivetrain drivetrain;
    private Turret turret;
    
    private Joystick driveStick;
    private Joystick turretStick;
    
    private Compressor compressor;
    private AxisCamera rufus;
    private AnalogChannel gyro;

    private boolean inHighGear, prevInHighGear;
    private boolean inLowGear, prevInLowGear;

    private PIDController charlieCharge;

    private DriverStationLCD lcd;

    public RobotTemplate(){
        //drivetrain = new Drivetrain(true);
        drivetrain = new Drivetrain(false);
        turret = new Turret();
        driveStick = new Joystick(1); //Joystick plugged into USB Hub port 1
        turretStick = new Joystick(2);

        compressor = new Compressor(7,7); //Digital IO port 6, relay 1

        rufus = AxisCamera.getInstance();

        gyro = new AnalogChannel(1);
        charlieCharge = new PIDController(1,0,0,gyro,drivetrain);
        charlieCharge.disable();

        lcd = DriverStationLCD.getInstance();
    }

        /**
         * This function is called once each time the robot enters autonomous mode.
         */
        public void autonomous() {

        }

        /**
         * This function is called once each time the robot enters operator control.
         */
        public void operatorControl() {
            compressor.start();
            double angle = 0;
            while(isOperatorControl()){
                turret.update(-turretStick.getX()* 3.0/4, turretStick.getY()* 3.0/4);
                //long time = (long) driveStick.getThrottle() + 1; //-1<=throttle<=1 + 1
                //turret.setTime(time);
                //lcd.println(DriverStationLCD.Line.kUser2, 1, "Gyro Voltage: "+gyro.getAverageVoltage());
                ///lcd.updateLCD();
                if(driveStick.getRawButton(3)){
                    //charlieCharge.enable();
                    //charlieCharge.setSetpoint(angle);
                    drivetrain.update(0, -1);
                    lcd.println(DriverStationLCD.Line.kUser2, 1, "Charlie Charge!");
                }
                else{
                    //charlieCharge.disable();
                    //modify the raw input from the driveStick and then send it to the drive train to drive.
                    drivetrain.update(deadBandModifier(driveStick.getY()),deadBandModifier(driveStick.getRawAxis(4)));
                    //we update the angle here because we want it to persist in the Charlie Charge!
                    angle = gyro.getAverageVoltage();
                    lcd.println(DriverStationLCD.Line.kUser2, 1, "               ");
                }

                if(DriverStation.getInstance().getDigitalIn(3)){
                    //turret.fire();
                    turret.getFiringRelay().set(Value.kForward);
                    lcd.println(DriverStationLCD.Line.kMain6, 1, "Imma Firin Mah Cannon");
                    lcd.updateLCD();
                    /*try {
                        Image picture = rufus.getImage();
                        Date current = new Date();
                        picture.write("pic"+current.toString()+".bmp");
                        current = null;
                        picture.free();
                    } 
                    catch (Exception ex) {
                    }*/
                }
                else{
                    turret.getFiringRelay().set(Value.kOff);
                    lcd.println(DriverStationLCD.Line.kMain6, 1, "                       ");
                    lcd.updateLCD();
                }


                if(driveStick.getRawButton(6)){
                    this.inHighGear = false;
                    this.prevInHighGear = false;
                }
                else{
                    this.inHighGear = true;
                    if(!(this.inHighGear && this.prevInHighGear)){
                        drivetrain.setHigh();
                    }
                    this.prevInHighGear = true;
                }

                if(driveStick.getRawButton(7)){
                    this.inLowGear = false;
                    this.prevInLowGear = false;
                }
                else{
                    this.inLowGear = true;
                    if(!(this.inLowGear && this.prevInLowGear)){
                        drivetrain.setLow();
                    }
                    this.prevInLowGear = true;
                }

                //here, fido! There's a good boy.
                getWatchdog().feed();
       }
     }


        //If the joystick value is betwen -0.05 and 0.05, then set it to zero
        public double deadBandModifier(double value){

            //Dead Zone computation
            if(-DEAD_ZONE < value && DEAD_ZONE > value){
                value = 0;
            }

            //Exponential speed ramping function. Huge thanks to Ether on the Chief Delphi forum for this one.
            double stickSensitivity = driveStick.getThrottle();
            return stickSensitivity*value*value*value + (1-stickSensitivity)*value;
        }
}

