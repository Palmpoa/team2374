/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.PIDController;
import edu.wpi.first.wpilibj.PIDOutput;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.SpeedController;

/**
 *
 * @author jhsuser
 */
public class Drivetrain implements PIDOutput{
    
    //these constants represent the motor ports that the default constructor will
    //assign to the port and starboard wheels.
    private final static int DEFAULT_MOTOR_PORT_PORT1 = 5;
    private final static int DEFAULT_MOTOR_PORT_PORT2 = 6;
    private final static int DEFAULT_MOTOR_PORT_STARBOARD1 = 3;
    private final static int DEFAULT_MOTOR_PORT_STARBOARD2 = 4;

    private Wheel portWheel, starboardWheel;

    private PIDController portPID, starboardPID;
    private PIDEncoder portEncoder;
    private PIDEncoder starboardEncoder;

    private boolean pidEnabled;

    private boolean highGear;
    private Solenoid highGearSolenoid;
    private Solenoid lowGearSolenoid;
    private final double CHARLIE_CHARGE_Y = -1.0; //lazy eletrical department

    public Drivetrain(boolean PID){
        this(DEFAULT_MOTOR_PORT_PORT1, DEFAULT_MOTOR_PORT_PORT2,
                DEFAULT_MOTOR_PORT_STARBOARD1, DEFAULT_MOTOR_PORT_STARBOARD2, 1,2,3,4,5,6,PID);
    }

    public Drivetrain(int portMotor1Port, int portMotor2Port, int starboardMotor1Port, int starboardMotor2Port,
                        int portEncoderPort1, int portEncoderPort2, int starboardEncoderPort1, int starboardEncoderPort2, int lgSolenoid,
                        int hgSolenoid, boolean PIDEnabled){

        portWheel = new Wheel(portMotor1Port, portMotor2Port);
        starboardWheel = new Wheel(starboardMotor1Port, starboardMotor2Port);

        portEncoder = new PIDEncoder(new Encoder(portEncoderPort1, portEncoderPort2));
        starboardEncoder = new PIDEncoder(new Encoder(starboardEncoderPort1, starboardEncoderPort2));

        //TODO: MAKE CONSTANTS FOR PID
        portPID = new PIDController(1,0,0,portEncoder,portWheel);
        starboardPID = new PIDController(1,0,0,starboardEncoder,starboardWheel);
        this.pidEnabled = PIDEnabled;
        if(this.pidEnabled){
            portEncoder.run();
            starboardEncoder.run();
            portPID.enable();
            starboardPID.enable();
        }

        highGearSolenoid = new Solenoid(hgSolenoid);
        lowGearSolenoid = new Solenoid(lgSolenoid);
        highGear = true;
    }

    public void update(double leftSpeed, double rightSpeed){  //-1<=x<=1, -1<=y<=1
        //double rotate = deadbandModifier(x); //horizontal axis
        //double move = deadbandModifier(y); //vertical axis

        //Speeds for the starboard and port motors, handed to PID later
        double speedPort = 0;
        double speedStarboard = 0;

        /*//Code courtesy of the WPILib RobotDrive arcade drive method, thanks guys!
        if (move > 0.0) {
            if (rotate > 0.0) {
                speedPort = move - rotate;
                speedStarboard = Math.max(move, rotate);
            } else {
                speedPort = Math.max(move, -rotate);
                speedStarboard = move + rotate;
            }
        } else {
            if (rotate > 0.0) {
                speedPort = -Math.max(-move, rotate);
                speedStarboard = move + rotate;
            } else {
                speedPort = move - rotate;
                speedStarboard = -Math.max(-move, -rotate);
            }
        }*/
        speedPort = deadbandModifier(leftSpeed);
        speedStarboard = deadbandModifier(-rightSpeed);
        
        

        if(this.pidEnabled){
            //Scale down the speed by a couple thousand to something the SpeedControllers can handle
            portPID.setSetpoint(speedPort);
            starboardPID.setSetpoint(speedStarboard);
        }
        else{
            portWheel.setSpeed(speedPort);
            starboardWheel.setSpeed(speedStarboard);
        }
    }
    
    public void switchGears(){
        highGear = !highGear; //toggle the mode
        highGearSolenoid.set(highGear);
        lowGearSolenoid.set(!highGear);
    }

    public void setHigh(){
        highGearSolenoid.set(true);
        lowGearSolenoid.set(false);
    }
    public void setLow(){
        highGearSolenoid.set(false);
        lowGearSolenoid.set(true);
    }

    public double deadbandModifier(double x){
        if(Math.abs(x)<=0.05) return 0;
        return x;
    }

    /*
     * This method is for the DriveTrain to be used in the Charlie Charge
     */
    public void pidWrite(double output) {
        output = this.deadbandModifier(output*.4 - 1);
        update(output,CHARLIE_CHARGE_Y);
    }

    //Declare this as a PIDOutput for the PIDController to handle
    public class Wheel implements PIDOutput{

        //Super shifter has two motors on one wheel that should run at the same speed
        SpeedController motorOne, motorTwo;

        public Wheel(int one, int two){
            motorOne = new Jaguar(one);
            motorTwo = new Jaguar(two);
        }

        //Both motors have to go at the same speed
        public void setSpeed(double speed){
            motorOne.set(speed);
            motorTwo.set(speed);
        }

        public SpeedController getMotorOne(){
            return motorOne;
        }
        public SpeedController getMotorTwo(){
            return motorTwo;
        }

        //Only required method by the interface
        public void pidWrite(double output) {
            setSpeed(output);
        }
    }
}
