/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.SpeedController;

/**
 *
 * @author robotics
 */
public class DriveSystem {
    private SpeedController leftMotor;
    private SpeedController rightMotor;
    private final static int LEFT_MOTOR_PORT = 4;
    private final static int RIGHT_MOTOR_PORT = 2;

    public  DriveSystem(int leftPort, int rightPort){
        leftMotor = new Jaguar(leftPort);
        rightMotor = new Jaguar(rightPort);

    }

    public DriveSystem(){
        this(LEFT_MOTOR_PORT, RIGHT_MOTOR_PORT);
    }

    public void Update(double left, double right){
        leftMotor.set(-left); //-1 to 1
        rightMotor.set(right);

    }
}
