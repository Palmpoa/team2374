/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.SpeedController;

/**
 *
 * @author shivani
 */
public class Manipulator {

    private static final boolean EXTEND = true;
    private static final boolean RETRACT = false;

    private static final boolean UP = true;
    private static final boolean DOWN = false;

    private Solenoid pusher;
    private final static int PUSHER_SOLENOID_PORT = 1;
    private boolean pushing;

    private SpeedController scooper;
    private final static int SCOOPER_MOTOR_PORT = 1;
    private boolean scooping;

    public Manipulator(int pusherPort, int scooperPort){
        pusher = new Solenoid(pusherPort);
        scooper = new Jaguar(scooperPort);
        pushing = true;
    }

    public Manipulator(){
        this(PUSHER_SOLENOID_PORT, SCOOPER_MOTOR_PORT);
    }


    public void push(){
        pusher.set(false);
    }
    public void pushStop(){
        pusher.set(true);
    }


    public void scoopForward(){
        scooper.set(1);
    }
    public void scoopStop(){
        scooper.set(0);
    }
    public void scoopReverse(){
        scooper.set(-1);
    }

}

