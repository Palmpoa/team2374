/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package com.team2374;


import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.camera.AxisCamera;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Main extends SimpleRobot {
    private Joystick joyStick1;
    private Joystick joyStick2;
    private Manipulator manipulator;
    private boolean scoopUp;
    private boolean prevScoopUp;
    private DriveSystem driveSystem;
    private Compressor compressor;
    private AxisCamera rufus;

    public Main(){
        joyStick1 = new Joystick(1);
        joyStick2 = new Joystick(2);
        driveSystem  = new DriveSystem();
        manipulator = new Manipulator();
        compressor = new Compressor(1,1); //Digital IO 1, Relay 1
        rufus = AxisCamera.getInstance();
    }

    public void autonomous() {
        
    }


    public void operatorControl() {
        compressor.start();
        while(isOperatorControl()){
            driveSystem.Update(joyStick1.getY(), joyStick2.getY());
        
            if(joyStick1.getTrigger()){
                manipulator.push(); }
            else{
                manipulator.pushStop();
            }

            if(joyStick1.getRawButton(6)){
               manipulator.scoopForward();
            }
            else if(joyStick1.getRawButton(7)){
                manipulator.scoopReverse();
            }
            else{
                manipulator.scoopStop();
            }

            getWatchdog().feed();
        }

    
    }
}


