/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.can.CANTimeoutException;

/**
 *
 * @author robotics
 */
public class Drivetrain {

    public static final double DEADBAND = 0.05;

    Wheel leftWheel, rightWheel;
    

    public Drivetrain() throws CANTimeoutException{
        leftWheel = new Wheel(3,4,1,2);
        rightWheel = new Wheel(5,6,3,4);

    }

    //Make sure these inputs are in the proper range!
    public void update(double y1, double y2) throws CANTimeoutException{
        leftWheel.set(y1);
        rightWheel.set(y2);
    }
    public void shiftGears(boolean gear){
        leftWheel.shift(gear);
        rightWheel.shift(gear);
    }
    public void shift(){
        leftWheel.shift();
        rightWheel.shift();
    }

    public double deadbandModifier(double input){
        if(Math.abs(input) < DEADBAND) return 0.0;
        if(input > 1) return 1;
        if(input < -1) return -1;
        return input;
    }
}
