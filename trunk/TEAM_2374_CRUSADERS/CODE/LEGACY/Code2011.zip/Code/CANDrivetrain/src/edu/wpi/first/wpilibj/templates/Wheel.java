/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.CANJaguar.ControlMode;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.can.CANTimeoutException;

/**
 *
 * @author robotics
 */
public class Wheel {

    public static double kP = 0.1, kI = 0.0, kD = 0.0;
    public static boolean HIGH_GEAR = true, LOW_GEAR = false;

    CANJaguar primaryMotor,   //The Jaguar with the Encoder
              secondaryMotor; //The copycat Jaguar

    Solenoid lowGear, highGear;


    public Wheel(int primaryID, int secondaryID, int highGearPort, int lowGearPort) throws CANTimeoutException{
      
        primaryMotor = new CANJaguar(primaryID, CANJaguar.ControlMode.kPercentVbus); //Change to SpeedMode later
        //secondaryMotor = new CANJaguar(secondaryID, CANJaguar.ControlMode.kPercentVbus);

        //lowGear = new Solenoid(lowGearPort); lowGear.set(true);
        //highGear = new Solenoid(highGearPort); highGear.set(false);


        /*primaryMotor.setPID(kP, kI, kD);
        primaryMotor.setSpeedReference(CANJaguar.SpeedReference.kQuadEncoder);
        primaryMotor.enableControl();*/

    }

    //Make sure you pass in the right units!
    public void set(double speed) throws CANTimeoutException{
        if(primaryMotor.getControlMode() == ControlMode.kPercentVbus){
            primaryMotor.setX(speed); //This should be in PWM range
            //secondaryMotor.setX(speed);
        }
        if(primaryMotor.getControlMode() == ControlMode.kSpeed){
            primaryMotor.setX(speed); //This should be in rotations per second
            //secondaryMotor.setX(primaryMotor.getOutputVoltage() / primaryMotor.getBusVoltage());
        }

    }

    public void shift(boolean gear){
        if(gear == HIGH_GEAR){ //Entirely for readability
            highGear.set(true);
            lowGear.set(false);
        }
        if(gear == LOW_GEAR){
            highGear.set(false);
            lowGear.set(true);
        }
    }
    
    public void shift(){
        highGear.set(!highGear.get());
        lowGear.set(!lowGear.get());
    }

    


}
