/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.DigitalInput;

/**
   
 * @author robotics
 */
public class LineSensorGroup {

    private DigitalInput ls1, ls2, ls3;

    public LineSensorGroup(int one, int two, int three){
        ls1 = new DigitalInput(one);
        ls2 = new DigitalInput(two);
        ls3 = new DigitalInput(three);
    }

    public boolean getMiddle(){
        if(ls1.get()==false && ls2.get()==true && ls3.get()==false) //on the line
            return true;
        if(ls1.get()==true && ls2.get()==true && ls3.get()==false) //improbable
            return true;
        if(ls1.get()==false && ls2.get()==true && ls3.get()==true) //improbable
            return true;
        else
            return false;
    }

    public boolean getLeft(){
        if(ls1.get()==true && ls2.get()==false && ls3.get()==false) //too far left
            return true;
        else
            return false;
    }

    public boolean getRight(){
        if(ls1.get()==false && ls2.get()==false && ls3.get()==true) //too far right
            return true;
        if(ls1.get()==true && ls2.get()==false && ls3.get()==true) //at y, automatically turn left (assumes too far right)
            return true;
        else
            return false;
    }

    public boolean atT(){
        if(ls1.get()==true && ls2.get()==true && ls3.get()==true) //at the T
            return true;
        else
            return false;
    }
}
