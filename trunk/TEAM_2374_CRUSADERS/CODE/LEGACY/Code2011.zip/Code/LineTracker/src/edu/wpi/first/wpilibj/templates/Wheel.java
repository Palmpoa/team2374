/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Jaguar;

/**
 *
 * @author robotics
 */
public class Wheel{ //It controls itself!!!

    //Static variables
    private static final double DEFAULT_TIMEOUT = 1000; //Safety time out for the motors


    //The super shifters have 2 motors to one gearbox
    private Jaguar motorOne;
    private Jaguar motorTwo;



    /**
     * Constructs a Wheel object with 2 Jaguars. Enables the safety to 1 second
     * @param motor1Port The port for one motor of the wheel
     * @param motor2Port The port for another motor of the wheel
     */
    public Wheel(int motor1Port, int motor2Port){

        //The wheel controls both motors
        motorOne = new Jaguar(motor1Port);
        motorTwo = new Jaguar(motor2Port);

        //No more global watchdog, now there are "watchdogs" called MotorSafety's on the motors
        motorOne.setSafetyEnabled(true); motorOne.setExpiration(DEFAULT_TIMEOUT);
        motorTwo.setSafetyEnabled(true); motorTwo.setExpiration(DEFAULT_TIMEOUT);
    }

    /**
     * Directly sets the wheel's speed. Use this without PID
     * @param speed The speed to apply to both motors of the Super Shifter
     */
    public void set(double speed){
        motorOne.set(speed);
        motorTwo.set(speed);
    }





}
