/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.Timer;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Main extends SimpleRobot {
    /**
     * This function is called once each time the robot enters autonomous mode.
     */

    LineSensorGroup lsg   = new LineSensorGroup(1,2,3);
    Drivetrain robot = new Drivetrain ();

    final int middle = 2;
    final int left = 1;
    final int right = 3;
    final int stop = 0;

    public void autonomous() {
        getWatchdog().feed();

        int last = middle;  //last line sensor value
        while(this.isEnabled() && this.isAutonomous()) {
            if(lsg.getMiddle()) {
                last = middle;
            } if (lsg.getLeft()) {
                last = left;
            } if (lsg.getRight()) {
                last = right;
            } if (lsg.atT()) {
                last = stop;
            }

            if (lsg.allAreOff()) {
                if (last == left) {
                    robot.update(1, 0.8);  //forward and right
                    System.out.println("Left");
                } else if (last == middle) {
                    robot.update(1, 1);    //straight forward
                    System.out.println("Forward");
                } else if (last == right) {
                    robot.update(0.8, 1);  //forward and left
                    System.out.println("Right");
                } else if (last ==stop) {
                    robot.update(0,0); //stop
                    System.out.println("Stopping");
                }
            }

            if (lsg.allAreOn()) {
                if (last == middle) {
                    robot.update(0, 0);
                    System.out.println("Stopping");
                    break;
                }
            }
            Timer.delay(0.05);
            this.getWatchdog().feed();
        }
    }
}
