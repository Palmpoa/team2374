package edu.wpi.first.wpilibj.templates;

import com.team2374.Drivetrain;
import com.team2374.Wheel;
import edu.wpi.first.wpilibj.Gyro;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author robotics
 */
public class AutoTurn {
public static final double DEADBAND_SIZE = 0.05;
private Gyro gyro;
    private Wheel leftWheel, rightWheel;

    public AutoTurn(){
        leftWheel = new Wheel(1,2);
        rightWheel = new Wheel(3,4);
    }

    /**
     * Accounts a deadband for a value
     * @param input The value to adjust
     * @return A deadband adjusted value
     */
    public double deadBandModifier(double input){
        if(Math.abs(input)<= DEADBAND_SIZE) return 0;
        return input;
    }

    //Tank drive right now
    public void update(double stick1Y, double stick2Y){

        double temp1 = deadBandModifier(stick1Y);
        double temp2 = deadBandModifier(stick2Y);

        //This should be in its own function. It just clamps the joystick to -1 to 1
        if(temp1 > 1) temp1 = 1;
        if(temp1 < -1) temp1 = -1;
        if(temp2 > 1) temp2 = 1;
        if(temp2 < -1) temp2 = -1;

        leftWheel.set(temp1);
        rightWheel.set(temp2); //Currently there is no right wheel
    }

    public Wheel getRightWheel(){ return rightWheel; }
    public Wheel getLeftWheel() { return leftWheel; }


 
    public void AutoTurn(double angleTarget){
        while(gyro.getAngle()!=angleTarget){
            double percent = gyro.getAngle()/angleTarget;
            if(angleTarget < 0 && angleTarget> -90){
            leftWheel.set(0);
            rightWheel.set(percent);}
            else
            leftWheel.set(percent);
            rightWheel.set(0);
            //right autoturn
        }
    }
  
    public void AutoUpdate(double angle){
        if(gyro.getAngle() != angle){
            if(angle < 0 && angle> -90){
            leftWheel.set(0);
            rightWheel.set(angle/100);}
            else{
            leftWheel.set(angle/100);
            rightWheel.set(0); }
            angle-=1;
        }
    }
    
    public void ManualUpdate(double a){
        if(gyro.getAngle()!=a){
             if(a < 0 && a> -90){
            leftWheel.set(0);
            rightWheel.set(1);}
            else{
            leftWheel.set(1);
            rightWheel.set(0); }
        }
    }
    //Operator Control:
    //left and right trigger...maybe
}

