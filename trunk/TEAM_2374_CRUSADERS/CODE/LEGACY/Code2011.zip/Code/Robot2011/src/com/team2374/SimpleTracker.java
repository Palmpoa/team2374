/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import com.team2374.drivetrain.Drivetrain;
import edu.wpi.first.wpilibj.DigitalInput;

/**
 *
 * @author robotics
 */
public class SimpleTracker {

    DigitalInput left, right, middle;
    Drivetrain drivetrain;

    public SimpleTracker(Drivetrain d){
        drivetrain = d;
        left = new DigitalInput(1);
        middle = new DigitalInput(3);
        right = new DigitalInput(5);
    }

    public void followLine(){
        int value = 4*(left.get()?1:0) + 2*(middle.get()?1:0) + (right.get()?1:0);

        switch(value){
            case 2: //on line
                drivetrain.update(-0.5, 0.5);
                break;
            case 1: //too far left, turn right
                drivetrain.update(0, -0.3);
                break;
            case 4: //too far right, turn left
                drivetrain.update(-0.3, 0);
                break;
            case 0:
                drivetrain.update(0.3,0);
                break;
            case 7:
                drivetrain.update(0,0);
                break; //you made it to the T!
            case 6:
            case 3:
                drivetrain.update(-0.5, -0.5); //let it go off course
                break;
            default:
                drivetrain.update(0.3,0);
                break;

        }
    }

}
