/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374.scoring;

import edu.wpi.first.wpilibj.Victor;

/**
 *
 * @author robotics
 */
public class Deployment {
    Victor zeMoto;

    public Deployment(int deploymentPort){
        zeMoto = new Victor(deploymentPort);
    }

    public Deployment(){
        this(8); //Ask Sheedy about this
    }

    public void update(int direction){ //-1, 0, 1
        if(direction == 1) zeMoto.set(1.0); 
        else if(direction == 0) zeMoto.set(0);
        else if (direction == -1) zeMoto.set(-1.0);
    }
    public void updateBackward(boolean on){
        if(on) zeMoto.set(-.25);
        else zeMoto.set(0);
    }
}