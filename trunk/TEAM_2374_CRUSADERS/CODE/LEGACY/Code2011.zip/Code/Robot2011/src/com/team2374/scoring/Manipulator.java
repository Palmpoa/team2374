/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374.scoring;

import edu.wpi.first.wpilibj.Solenoid;

/**
 *
 * @author robotics
 */
public class Manipulator {
    Solenoid up, down;

    public Manipulator(){
        down = new Solenoid(7);
        up = new Solenoid(6);
        up.set(false);
        down.set(true);
    }

    public void goUp(){
        up.set(true);
        down.set(false);
    }
    public void goDown(){
        up.set(false);
        down.set(true);
    }

    public void set(boolean up){
        if(up) goUp();
        else goDown();
    }



    
}
