/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package com.team2374;


import com.team2374.scoring.Elevator;
import com.team2374.scoring.Manipulator;
import com.team2374.drivetrain.Drivetrain;
import com.team2374.scoring.Deployment;
import edu.wpi.first.wpilibj.*;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends SimpleRobot {

    public static final double DEADBAND_SIZE = 0.05;

    Drivetrain drivetrain;

    Elevator elevator;
    double elevatorTargetPosition;

    Deployment deployment;
    boolean on;


    Manipulator manipulator;
    boolean manipulatorPosition;

    Joystick driveStick, elevatorStick;

    Compressor compressor;
    Relay compressorRelay;

    DriverStationLCD lcd;

    boolean gearToggle, prevGearToggle;

    boolean isTryingToScore;

    public Robot(){
        drivetrain = new Drivetrain();

        elevator = new Elevator();
        elevatorTargetPosition = 0;

        deployment = new Deployment();
        on = false;

        //compressorRelay = new Relay(1);
        compressor = new Compressor(1,1);

        manipulator = new Manipulator();
        manipulatorPosition = false;

        driveStick = new Joystick(1);
        elevatorStick = new Joystick(2);

        lcd = DriverStationLCD.getInstance();

        gearToggle = true;
        prevGearToggle = true;

        isTryingToScore = false;

    }

    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    public void autonomous() {
        //TODO: Create a set of functions that execute the autonomous routine
        compressor.start();
        //compressorRelay.set(Relay.Value.kForward);
        elevatorTargetPosition = 0;
        Timer timer = new Timer();
        timer.start();
        while(timer.get() < 0.0625){ //in seconds not microseconds!
            //drivetrain.update(-1.0/2,1.0/2);
            //deployment.update(1); //go forward for a quarter of a second
            //elevatorTargetPosition += 15;
            //elevator.Update(elevatorTargetPosition);
        }
        //drivetrain.update(0,0);
        
        //int value = 4*(left.get()?1:0) + 2*(middle.get()?1:0) + (right.get()?1:0);
        /*boolean done = false;
        while(!done){
            done = elevator.Update(6000);
        }
        tryScoring();

        done=false;
        while(!done){
            done = elevator.Update(0);
        }*/
        manipulator.goDown();
    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {
        //compressorRelay.set(Relay.Value.kForward);
        compressor.start();
        elevatorTargetPosition = 0;
        while(isOperatorControl()){
            if(!isTryingToScore){
                driveStickHandler();
                elevatorStickHandler();
            }
            else{
                tryScoring();
            }
            //lcd.println(DriverStationLCD.Line.kUser4, 1, "Compressor: "+compressor.getPressureSwitchValue());
            //lcd.println(DriverStationLCD.Line.kUser5, 1, "Pressure Switch: "+compressor.enabled());
            lcd.updateLCD();
        }
       elevator.setDistance(0);
    }


    /*
     * Control Scheme:
     * Left stick Y = Left Side of the robot
     * Right stick Y = Right side of the robot
     * Left bumper = Rotate 90 degrees counter clockwise
     * Right bumper = Rotate 90 degress clockwise
     * 2: Toggle Gears
     */
    public void driveStickHandler(){
        
        double stick1 = deadBandModifier(driveStick.getRawAxis(2));
        double stick2 = deadBandModifier(driveStick.getRawAxis(4));


        drivetrain.update(stick1, -stick2);

        if(driveStick.getRawButton(7)) return; //TODO: Rotate counter clockwise
        if(driveStick.getRawButton(8)) return; //TODO: Rotate clockwise

        if(driveStick.getRawButton(2)){
            gearToggle = false;
            prevGearToggle = false;
        } else{
            gearToggle = true;
            if(!(gearToggle && prevGearToggle)){
                drivetrain.shift();
            }
            prevGearToggle = true;
        }
    }

    /*
     * Control Scheme:7
     * Tophat Up: Elevator up
     * Tophad Down: Elevator down
     * 1: Bottom Row
     * 2: Middle Row
     * 3: Top Row
     * 4: Feeder Station
     * 9: Reset to Starting Configuration
     * 8: Extend the minibot deployment (Hold down)
     * 7: Retract the minibot deployment (Hold down)
     * 5: Manipulator Down
     * 6: Manipulator Up
     * 10: Try Scoring (temporarily disables control)
     */
    public void elevatorStickHandler(){
        double elevatorStickY = deadBandModifier(elevatorStick.getY());
        //prevent the elevator from updating
        if(elevatorStickY < 0 && elevatorTargetPosition < 3250) elevatorTargetPosition += 3;
        else if(elevatorStickY > 0 && elevatorTargetPosition > 0) elevatorTargetPosition -= 3;


        /*if(elevatorStick.getRawButton(9)) elevatorTargetPosition = 0;
        else if(elevatorStick.getRawButton(1)) elevatorTargetPosition = 500;
        else if(elevatorStick.getRawButton(2)) elevatorTargetPosition = 1000;
        else if(elevatorStick.getRawButton(3)) elevatorTargetPosition = 1500;
        else if(elevatorStick.getRawButton(4)) elevatorTargetPosition = 2000; */

        if(elevatorStick.getRawButton(5)) manipulator.goUp();
        else if(elevatorStick.getRawButton(6)) manipulator.goDown();

        //if(elevatorStick.getRawButton(10)) isTryingToScore = true;

        lcd.println(DriverStationLCD.Line.kMain6, 1,"Elevator Target: "+elevatorTargetPosition);
        lcd.println(DriverStationLCD.Line.kUser2, 1,"Current: "+elevator.distance());

        elevator.setDistance(elevatorTargetPosition);
        //manipulator.set(manipulatorPosition);

        //if(elevatorStick.getRawButton(8)) deployment.update(true);
        //else deployment.update(false);
        //deployment.update(on);

        if(elevatorStick.getRawButton(8)) deployment.update(1);
        else if(elevatorStick.getRawButton(7)) deployment.update(-1);
        else deployment.update(0);

    }

    //Give it the old college try! Note: You will lose control for couple of seconds
    public void tryScoring(){
        Timer timer = new Timer();
        timer.start();
        while(timer.get() < 0.5){
            drivetrain.update(-0.2, 0.2); //Move forward
        }
        timer.stop();
        timer.reset();
        boolean done = false;
        elevatorTargetPosition -= 500; //move the elevator down
        while(!done){
            done = elevator.Update(elevatorTargetPosition);
        }
        timer.start();
        while(timer.get() < 0.5){
            drivetrain.update(0.2,-0.2); //Move backwards
        }
        timer.stop();

        isTryingToScore = false;

        
    }

        /**
     * Accounts a deadband for a value
     * @param input The value to adjust
     * @return A deadband adjusted value
     */
    public double deadBandModifier(double input){
        if(Math.abs(input)<= DEADBAND_SIZE) return 0;

        if(input > 1) return 1;
        if(input < -1) return -1;

        return input;
    }
}
