/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374.drivetrain;

import edu.wpi.first.wpilibj.Gyro;
import edu.wpi.first.wpilibj.Solenoid;

/**
 *
 * @author robotics
 */
public class Drivetrain {



    private Wheel leftWheel, rightWheel;

    private Solenoid highGear, lowGear;

    public Drivetrain(){
        rightWheel = new Wheel(3,4);
        leftWheel = new Wheel(5,6);

        highGear = new Solenoid(3); //highGear.set(false);
        lowGear = new Solenoid(4); //lowGear.set(true);

    }

    public void setSafetyEnabled(boolean safety){
        rightWheel.setSafetyEnabled(safety);
        leftWheel.setSafetyEnabled(safety);
    }
    public void setExpiration(double timeout){
        rightWheel.setExipiration(timeout);
        leftWheel.setExipiration(timeout);
    }



    //Tank Drive
    public void update(double stick1Y, double stick2Y){        
        leftWheel.set(stick1Y);
        rightWheel.set(stick2Y); //Currently there is no right wheel
    }


    //This will be used by the Line tracker maybe
    public void arcadeUpdate(double move, double rotate){

        //Speeds for the starboard and port motors, handed to PID later
        double speedPort = 0;
        double speedStarboard = 0;

        //Code courtesy of the WPILib RobotDrive arcade drive method, thanks guys!
        if (move > 0.0) {
            if (rotate > 0.0) {
                speedPort = move - rotate;
                speedStarboard = Math.max(move, rotate);
            } else {
                speedPort = Math.max(move, -rotate);
                speedStarboard = move + rotate;
            }
        } else {
            if (rotate > 0.0) {
                speedPort = -Math.max(-move, rotate);
                speedStarboard = move + rotate;
            } else {
                speedPort = move - rotate;
                speedStarboard = -Math.max(-move, -rotate);
            }
        }

        leftWheel.set(speedPort);
        rightWheel.set(speedStarboard);
    }

    public Wheel getRightWheel(){ return rightWheel; }
    public Wheel getLeftWheel() { return leftWheel; }

    public void shift(boolean toHighGear){
        highGear.set(toHighGear);
        lowGear.set(!toHighGear);
    }
    public void shift(){
        shift(!highGear.get());
    }

}
