/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.team2374;

import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.PIDController;
import edu.wpi.first.wpilibj.PIDOutput;
import edu.wpi.first.wpilibj.SpeedController;

/**
 *
 * @author robotics
 */
public class Elevator implements PIDOutput {
private SpeedController elevator;
private final static int ELEVATOR_PORT = 2;
private Encoder elevatorEncoder;
public PIDController elevatorPID;

    public Elevator(int elevatorPort, int encoderAChannel, int encoderBChannel){
       elevator = new Jaguar(elevatorPort); //port???
       elevatorEncoder = new Encoder(encoderAChannel,encoderBChannel,true,EncodingType.k2X);
       elevatorEncoder.setPIDSourceParameter(Encoder.PIDSourceParameter.kDistance);
       elevatorEncoder.start();
       
       elevatorPID = new PIDController(0.1,0.05,0.0,elevatorEncoder,this);
       elevatorPID.setOutputRange(-1, 1);
       elevatorPID.setTolerance(2.5);
       //elevatorPID.enable();
    }

    public Elevator(){
        this(1,7,8);
    }

    public double distance(){
        double distance = elevatorEncoder.getDistance();
        return distance;
    }

      public void up(){
          elevator.set(-.75);
      }
      public void down(){
          elevator.set(.75);
      }
      public void stop(){
          elevator.set(0);
      }
      public void Base(){
            if (elevatorEncoder.getDistance() > 0){
                    down();
                    if(elevatorEncoder.getDistance() == 0)
                    stop();
                 }
      }
     /* public void LevelOne(){
           if(elevatorEncoder.getDistance() > 25){
                     ElevatorDown();
                     if(elevatorEncoder.getDistance() == 25)
                         ElevatorRest();
                 }
                 if(elevatorEncoder.getDistance() < 25){
                     ElevatorUp();
                     if(elevatorEncoder.getDistance() == 25)
                         ElevatorRest();
                 }
      }
      public void LevelTwo(){
          if(elevatorEncoder.getDistance() > 50){
                     ElevatorDown();
                     if(elevatorEncoder.getDistance() == 50)
                         ElevatorRest();
                 }
                 if(elevatorEncoder.getDistance() < 50){
                     ElevatorUp();
                     if(elevatorEncoder.getDistance() == 50)
                         ElevatorRest();
                 }
      }
      public void LevelThree(){
          if(elevatorEncoder.getDistance() > 75){
                     ElevatorDown();
                     if(elevatorEncoder.getDistance() == 75)
                         ElevatorRest();
                 }
                 if(elevatorEncoder.getDistance() < 75){
                     ElevatorUp();
                     if(elevatorEncoder.getDistance() == 75)
                         ElevatorRest();
                 }
      }
      public void LevelFour(){
        if(elevatorEncoder.getDistance() < 75){
                     ElevatorUp();
                     if(elevatorEncoder.getDistance() == 75)
                         ElevatorRest();
                 }

      }*/
      public void Update(double d){
          //if not enabled
          //elevatorPID.setSetpoint(d);
          setDistance(d);  
      }
    public void setDistance(double d){
          double percentError = (elevatorEncoder.getDistance() - d) / d;

          DriverStationLCD.getInstance().println(DriverStationLCD.Line.kMain6,1,
                  "Encoder: "+elevatorEncoder.getDistance());

          DriverStationLCD.getInstance().updateLCD();
          if(percentError > -0.02 && percentError < 0.02)
            stop();
          else if(elevatorEncoder.getDistance() < d)
            up();
          else if(elevatorEncoder.getDistance() > d)
            down();
    }

    public void pidWrite(double output) {
        DriverStationLCD lcd = DriverStationLCD.getInstance();
        lcd.println(DriverStationLCD.Line.kMain6, 1, "Elevator: "+elevatorEncoder.getDistance());
        lcd.println(DriverStationLCD.Line.kUser2, 1, "Output: "+output);
        lcd.updateLCD();
        elevator.set(-output/(elevatorPID.getSetpoint()*elevatorPID.getP())); //backwards!
    }
      //PIDController pid = new PIDController(double kP, double kI, double kD, elevatorEncoder,jag);

    }









      


  

